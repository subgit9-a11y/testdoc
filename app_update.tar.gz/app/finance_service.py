"""
Finance Service - Payouts, Commissions, and Wallets
Handles the 30% Admin commission / 70% Doctor share logic.
Backbone for Razorpay integrated withdrawals.
"""

import logging
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from app.database import db_manager

logger = logging.getLogger(__name__)

class FinanceService:
    """Manages the medical-fintech core of AyurEze"""
    
    ADMIN_COMMISSION_PERCENT = 30.0
    DOCTOR_SHARE_PERCENT = 70.0

    async def record_consultation_payment(self, doctor_id: str, consultation_id: str, total_fee: int, payment_id: str):
        """
        Processes a successful consultation payment.
        Updates doctor wallet and logs commission.
        """
        if not db_manager.is_connected():
            return False
            
        try:
            # 1. Calculate Split
            admin_cut = int(total_fee * (self.ADMIN_COMMISSION_PERCENT / 100))
            doctor_share = total_fee - admin_cut
            
            # 2. Update Consultation Record
            db_manager.client.table("consultations").update({
                "payment_status": "paid",
                "payment_id": payment_id,
                "total_fee": total_fee
            }).eq("consultation_id", consultation_id).execute()
            
            # 3. Update Doctor Wallet
            # UPSERT ensures wallet exists before update
            wallet_res = db_manager.client.table("doctor_wallets").select("*").eq("doctor_id", doctor_id).execute()
            if not wallet_res.data:
                db_manager.client.table("doctor_wallets").insert({
                    "doctor_id": doctor_id,
                    "total_earned": total_fee,
                    "available_balance": doctor_share,
                    "updated_at": datetime.now(timezone.utc).isoformat()
                }).execute()
            else:
                current_total = wallet_res.data[0].get("total_earned", 0)
                current_balance = wallet_res.data[0].get("available_balance", 0)
                
                db_manager.client.table("doctor_wallets").update({
                    "total_earned": current_total + total_fee,
                    "available_balance": current_balance + doctor_share,
                    "updated_at": datetime.now(timezone.utc).isoformat()
                }).eq("doctor_id", doctor_id).execute()
            
            logger.info(f"💰 Processed payout for {consultation_id}: Dr {doctor_id} (+{doctor_share}) | Admin (+{admin_cut})")
            return True
        except Exception as e:
            logger.error(f"Finance processing error for {consultation_id}: {e}")
            return False

    async def get_wallet_summary(self, doctor_id: str) -> Dict[str, Any]:
        """Fetch real-time earnings (Supabase + Legacy MySQL Interlink)"""
        if not db_manager.is_connected():
            return {"error": "Database disconnected"}
            
        total_earned = 0.0
        available_balance = 0.0
        withdrawn_amount = 0.0
        
        # 1. Fetch from New Supabase Ecosystem
        try:
            res = db_manager.client.table("doctor_wallets").select("*").eq("doctor_id", doctor_id).execute()
            if res.data:
                total_earned += float(res.data[0].get("total_earned", 0))
                available_balance += float(res.data[0].get("available_balance", 0))
                withdrawn_amount += float(res.data[0].get("withdrawn_amount", 0))
        except Exception as e:
            logger.warning(f"Supabase Wallet fetch failed (Table missing?): {e}")
            
        # 2. INTERLINK: Fetch from Legacy MySQL Ecosystem
        try:
            from app.admin_db import admin_db
            from sqlalchemy import text
            
            legacy_id = doctor_id.replace("DOC-", "")
            if admin_db.engine:
                with admin_db.get_session() as session:
                    # Sum all appointment fees for this legacy doctor
                    app_res = session.execute(
                        text("SELECT SUM(amount) as total FROM appointment WHERE doctor_id = :id"),
                        {"id": legacy_id}
                    ).mappings().first()
                    
                    if app_res and app_res['total']:
                        legacy_total = float(app_res['total'])
                        total_earned += legacy_total
                        
                        # Apply Astra's standard 70% doctor share consistency model for legacy earnings
                        legacy_balance = legacy_total * (self.DOCTOR_SHARE_PERCENT / 100)
                        available_balance += legacy_balance
                        
                        logger.info(f"🔄 Wallet Interlink: Added ₹{legacy_total} legacy earnings for {doctor_id}")
        except Exception as e:
            logger.warning(f"Legacy MySQL Wallet Interlink failed: {e}")
            
        return {
            "doctor_id": doctor_id,
            "total_earned": round(total_earned, 2),
            "available_balance": round(available_balance, 2),
            "withdrawn_amount": round(withdrawn_amount, 2)
        }

    async def request_withdrawal(self, doctor_id: str, amount: int) -> Dict[str, Any]:
        """Initiate a withdrawal request of 70% share"""
        if not db_manager.is_connected():
            return {"success": False, "error": "Database disconnected"}
            
        try:
            # Check Balance
            wallet = await self.get_wallet_summary(doctor_id)
            if wallet.get("available_balance", 0) < amount:
                return {"success": False, "error": "Insufficient balance"}
            
            # Split calculation for auditing
            admin_commission = int(amount * 0.3)
            payout_70 = amount - admin_commission
            
            # Create Request
            withdrawal_data = {
                "doctor_id": doctor_id,
                "amount": amount,
                "admin_commission_30": admin_commission,
                "doctor_payout_70": payout_70,
                "status": "pending"
            }
            res = db_manager.client.table("withdrawal_requests").insert(withdrawal_data).execute()
            
            # Deduct from Wallet (Prevent double spending)
            new_balance = wallet.get("available_balance", 0) - amount
            db_manager.client.table("doctor_wallets").update({
                "available_balance": new_balance,
                "updated_at": datetime.now(timezone.utc).isoformat()
            }).eq("doctor_id", doctor_id).execute()
            
            return {
                "success": True, 
                "message": "Withdrawal request pending admin approval",
                "request_id": res.data[0]["id"] if res.data else None
            }
            
        except Exception as e:
            logger.error(f"Withdrawal request failed: {e}")
            return {"success": False, "error": str(e)}

# Global Finance singleton
finance_service = FinanceService()
