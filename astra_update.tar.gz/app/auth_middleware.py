import logging
import time
from typing import Optional, Dict, List
from collections import defaultdict

from fastapi import Request, HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from app.auth import verify_token

logger = logging.getLogger(__name__)
security = HTTPBearer(auto_error=False)

class RateLimiter:
    """
    In-memory rate limiter using sliding window logic.
    """
    def __init__(self, requests_per_minute: int = 60):
        self.requests_per_minute = requests_per_minute
        self.requests: Dict[str, List[float]] = defaultdict(list)

    def is_allowed(self, client_id: str) -> bool:
        now = time.time()
        minute_ago = now - 60

        # Filter out timestamps older than 60 seconds
        self.requests[client_id] = [
            t for t in self.requests[client_id]
            if t > minute_ago
        ]

        if len(self.requests[client_id]) >= self.requests_per_minute:
            return False

        self.requests[client_id].append(now)
        return True

# Initialize global rate limiter
rate_limiter = RateLimiter(requests_per_minute=60)

async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)
) -> Optional[str]:
    """
    Dependency to get the UID if authenticated.
    Renamed from get_current_user_uid to match companion_api.py import.
    """
    if not credentials:
        return None

    try:
        token = credentials.credentials
        payload = verify_token(token)
        return payload.get("uid")
    except Exception as e:
        logger.error(f"Token verification failed: {str(e)}")
        # Return None so the endpoint can decide whether to block or allow anon
        return None

async def rate_limit_check(request: Request) -> None:
    """
    Dependency to enforce rate limits based on Client IP.
    """
    client_ip = request.client.host if request.client else "unknown"

    if not rate_limiter.is_allowed(client_ip):
        logger.warning(f"Rate limit exceeded for IP: {client_ip}")
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many requests. Please try again later."
        )

async def validate_user_access(
    user_id_from_request: str,
    authenticated_user: Optional[str] = None
) -> None:
    """
    Logic to ensure a user is only accessing their own resources.
    """
    if authenticated_user is None:
        return

    if user_id_from_request != authenticated_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: You cannot access another user's data."
        )
