"""
Enhanced AI Companion API - 100% Production Ready
Includes all bug fixes and new features
"""

from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone
import logging

# Core services
from app.companion_redis_manager import redis_companion_manager
from app.voice_service import voice_service
from app.conversation_pruner import conversation_pruner
from app.enhanced_input_validator import input_validator
from app.model_service import model_service
from app.ayurveda_model_service import ayurveda_model_service  # Custom Ayurveda model
from app.auth_middleware import rate_limit_check, get_current_user

logger = logging.getLogger(__name__)

# Router with rate limiting
router = APIRouter(
    prefix="/api/companion/v2",
    tags=["AI Companion Enhanced"],
    dependencies=[Depends(rate_limit_check)]
)

# ============ MODELS ============

class StartJourneyRequest(BaseModel):
    user_id: str
    health_concern: str
    language: Optional[str] = "en"
    initial_symptoms: Optional[List[str]] = None
    enable_voice: Optional[bool] = False

class StartJourneyResponse(BaseModel):
    success: bool
    journey_id: Optional[str]
    message: str
    welcome_message: str
    voice_audio_base64: Optional[str] = None

class ChatRequest(BaseModel):
    journey_id: str
    message: str
    language: Optional[str] = "en"
    enable_voice: Optional[bool] = False

class ChatResponse(BaseModel):
    success: bool
    response: str
    language: str
    voice_audio_base64: Optional[str] = None
    tokens_used: Optional[int] = None
    pruned: Optional[bool] = False

# ============ ENDPOINTS ============

@router.post("/journey/start", response_model=StartJourneyResponse)
async def start_journey_enhanced(
    data: StartJourneyRequest,
    current_user: Optional[str] = Depends(get_current_user)
):
    """
    Start companion journey with full validation and voice support
    """
    try:
        # Validate inputs
        is_valid_id, id_error = input_validator.validate_patient_id(data.user_id)
        if not is_valid_id:
            raise HTTPException(status_code=400, detail=id_error)
        
        is_valid_concern, sanitized_concern, concern_error = input_validator.validate_health_concern(data.health_concern)
        if not is_valid_concern:
            raise HTTPException(status_code=400, detail=concern_error)
        
        is_valid_lang, lang_error = input_validator.validate_language_code(data.language)
        if not is_valid_lang:
            raise HTTPException(status_code=400, detail=lang_error)
        
        # Create journey with Redis caching
        journey_id = await redis_companion_manager.start_companion_journey(
            user_id=data.user_id,
            health_concern=sanitized_concern,
            language=data.language,
            initial_symptoms=data.initial_symptoms
        )
        
        if not journey_id:
            raise HTTPException(status_code=500, detail="Failed to create journey")
        
        # Generate welcome message
        welcome_msg = f"Hello! I'm Astra, your AI wellness companion. I'm here to help you with {sanitized_concern}. How are you feeling today?"
        
        # Generate voice if requested
        voice_audio = None
        if data.enable_voice and voice_service.is_available():
            voice_audio = await voice_service.text_to_speech_base64(
                text=welcome_msg,
                language=data.language
            )
        
        return StartJourneyResponse(
            success=True,
            journey_id=journey_id,
            message="Journey started successfully",
            welcome_message=welcome_msg,
            voice_audio_base64=voice_audio
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Start journey error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/chat", response_model=ChatResponse)
async def chat_enhanced(
    data: ChatRequest,
    current_user: Optional[str] = Depends(get_current_user)
):
    """
    Enhanced chat via unified Astra Pipeline with voice support.
    """
    try:
        from app.astra.routes import pipeline_instance
        if not pipeline_instance:
            raise HTTPException(status_code=503, detail="Astra Pipeline not initialized")

        # Process through the unified pipeline
        result = await pipeline_instance.run(
            input_text=data.message,
            user_uuid=data.journey_id,
            channel="voice" if data.enable_voice else "app",
            metadata={"journey_id": data.journey_id, "feature": "companion_v2"}
        )

        response_text = result.get("response", "")
        
        # Generate voice if requested
        voice_audio = None
        if data.enable_voice and voice_service.is_available():
            voice_audio = await voice_service.text_to_speech_base64(
                text=response_text,
                language=data.language or result.get("language", "en")
            )

        return ChatResponse(
            success=True,
            response=response_text,
            language=data.language or result.get("language", "en"),
            voice_audio_base64=voice_audio,
            tokens_used=result.get("metadata", {}).get("tokens_used", len(response_text.split())),
            pruned=result.get("metadata", {}).get("pruned", False)
        )
        
    except Exception as e:
        logger.error(f"Enhanced chat error: {e}")
        raise HTTPException(status_code=500, detail=str(e))




# Journey and other management endpoints remain unchanged, but chat is now unified.



@router.get("/journey/{journey_id}")
async def get_journey_enhanced(
    journey_id: str,
    current_user: Optional[str] = Depends(get_current_user)
):
    """Get journey details with Redis caching"""
    try:
        journey = await redis_companion_manager.get_journey(journey_id)
        if not journey:
            raise HTTPException(status_code=404, detail="Journey not found")
        
        return {
            "success": True,
            "journey": journey
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get journey error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/voices")
async def get_available_voices(
    current_user: Optional[str] = Depends(get_current_user)
):
    """Get available ElevenLabs voices"""
    try:
        if not voice_service.is_available():
            return {
                "success": False,
                "message": "Voice service not configured",
                "voices": []
            }
        
        voices = await voice_service.get_available_voices()
        return {
            "success": True,
            "voices": voices or [],
            "message": "ElevenLabs voices available"
        }
    except Exception as e:
        logger.error(f"Get voices error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/health")
async def companion_health_check():
    """Health check for companion service"""
    return {
        "status": "healthy",
        "version": "2.0",
        "features": {
            "redis_cache": redis_companion_manager.client is not None,
            "voice_enabled": voice_service.is_available(),
            "conversation_pruning": True,
            "input_validation": True,
            "rate_limiting": True
        }
    }
