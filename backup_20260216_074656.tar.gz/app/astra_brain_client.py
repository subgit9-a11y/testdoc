"""
Astra Brain Client - Unified API Connector for api.ayureze.in
Version: 5.0.0 - ENHANCED WITH BUG FIXES
Description: Connects ALL AI endpoints to automate features with the Astra AI Model

🔧 FIXES APPLIED:
- ✅ Timeout increased: 60s → 120s
- ✅ Retry mechanism added (2 retries with exponential backoff)
- ✅ Session ID support added to all methods
- ✅ User context enrichment added
- ✅ Fallback responses improved
- ✅ Smart routing helper added
- ✅ Added get_brain_client dependency

Endpoints Connected:
- POST /v1/chat - Core conversational AI with RAG
- POST /v1/autopilot - Intent routing (Booking/Pharmacy/Chat)
- POST /v1/fill - Structured data extraction
- POST /v1/shop_assist - E-commerce product mapping
- POST /v1/extract_schedule - Prescription reminder extraction
- POST /v1/doctor_summary - Clinical scribe/summarization
- POST /v1/analyze_safety - Safety sentinel (PII, self-harm)
- POST /v1/detect_emotion - Sentiment analysis
- POST /v1/profile_analysis - Buddy matching/risk assessment
- POST /v1/generate_wellness - Meditation/yoga generation
- POST /v1/adjust_tone - Empathetic text rewriting
- GET /health - Health check
"""

import logging
import httpx
import asyncio
import json
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)

# ============================================================================
# Data Models
# ============================================================================

class Intent(str, Enum):
    """Autopilot intent types"""
    CHAT = "CHAT"
    SHOP_ASSIST = "SHOP_ASSIST"
    BOOKING = "BOOKING"
    UNKNOWN = "UNKNOWN"

@dataclass
class ChatResponse:
    answer: str
    mode: str
    success: bool = True

@dataclass  
class AutopilotResponse:
    intent: Intent
    status: str
    confidence: float = 1.0

@dataclass
class SafetyAnalysis:
    is_safe: bool
    flags: List[str]
    risk_level: str = "low"

@dataclass
class EmotionResult:
    emotion: str
    intensity: str
    confidence: float = 0.8

@dataclass
class ScheduleResult:
    reminders: List[Dict[str, Any]]
    raw_json: str

# ============================================================================
# Main Client
# ============================================================================

class AstraBrainClient:
    """
    Unified client for all Astra AI Brain endpoints at api.ayureze.in
    """
    
    def __init__(self, base_url: str = "https://api.ayureze.in"):
        self.base_url = base_url.rstrip("/")
        self.timeout = httpx.Timeout(120.0, read=120.0, connect=15.0)
        self._connected = False
        logger.info(f"🧠 AstraBrainClient initialized → {self.base_url}")
    
    # =========================================================================
    # Retry Mechanism
    # =========================================================================
    
    async def _make_request_with_retry(
        self, 
        method: str, 
        url: str, 
        max_retries: int = 2,
        **kwargs
    ) -> httpx.Response:
        """
        Make HTTP request with retry logic
        """
        last_error = None
        
        for attempt in range(max_retries):
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    if method.upper() == "POST":
                        response = await client.post(url, **kwargs)
                    elif method.upper() == "GET":
                        response = await client.get(url, **kwargs)
                    else:
                        raise ValueError(f"Unsupported method: {method}")
                    
                    if response.status_code < 500:
                        return response
                        
                    logger.warning(f"⚠️ Attempt {attempt + 1}/{max_retries} failed with {response.status_code}")
                    last_error = f"Status {response.status_code}"
                    
            except (httpx.TimeoutException, httpx.ConnectError) as e:
                logger.warning(f"⚠️ Attempt {attempt + 1}/{max_retries} failed: {e}")
                last_error = str(e)
            except Exception as e:
                logger.error(f"❌ Unexpected error on attempt {attempt + 1}: {e}")
                last_error = str(e)
                
            if attempt < max_retries - 1:
                wait_time = 2 ** (attempt + 1)
                logger.info(f"⏳ Waiting {wait_time}s before retry...")
                await asyncio.sleep(wait_time)
        
        raise Exception(f"Request failed after {max_retries} attempts: {last_error}")
    
    # =========================================================================
    # Health & Connection
    # =========================================================================
    
    async def check_health(self) -> Dict[str, Any]:
        """
        GET /health - Check if the Brain is online
        """
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(f"{self.base_url}/health")
                if response.status_code == 200:
                    data = response.json()
                    self._connected = True
                    logger.info(f"✅ Astra Brain Online: {data}")
                    return {"status": "online", "data": data}
                else:
                    logger.warning(f"⚠️ Brain returned {response.status_code}")
                    return {"status": "degraded", "code": response.status_code}
        except Exception as e:
            logger.error(f"❌ Brain health check failed: {e}")
            return {"status": "offline", "error": str(e)}
    
    async def ensure_connected(self) -> bool:
        """Ensure connection is established"""
        if not self._connected:
            result = await self.check_health()
            self._connected = result.get("status") == "online"
        return self._connected
    
    # =========================================================================
    # 1. Core Chat & Intelligence
    # =========================================================================
    
    async def chat(
        self, 
        query: str, 
        language: str = "en",
        session_id: Optional[str] = None,
        use_rag: bool = True
    ) -> ChatResponse:
        """
        POST /v1/chat - Main conversational interface with RAG + Agent Persona
        """
        try:
            payload = {
                "query": query,
                "language": language,
                "use_rag": use_rag
            }
            if session_id:
                payload["session_id"] = session_id
            
            response = await self._make_request_with_retry(
                "POST",
                f"{self.base_url}/v1/chat",
                json=payload
            )
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Chat response [mode: {data.get('mode', 'unknown')}]")
                return ChatResponse(
                    answer=data.get("answer", ""),
                    mode=data.get("mode", "unknown"),
                    success=True
                )
            else:
                logger.error(f"❌ Chat failed: {response.status_code}")
                return ChatResponse(
                    answer="I'm having trouble connecting. Please try again.",
                    mode="error",
                    success=False
                )
        except Exception as e:
            logger.error(f"❌ Chat error: {e}")
            return ChatResponse(
                answer="I'm experiencing technical difficulties. Please try again in a moment.",
                mode="error_fallback",
                success=False
            )
    
    async def chat_with_context(
        self,
        query: str,
        user_context: Optional[Dict[str, Any]] = None,
        language: str = "en",
        session_id: Optional[str] = None
    ) -> ChatResponse:
        """
        Enhanced chat with user context embedding
        """
        if user_context:
            context_str = "Patient Profile:\n"
            if "age" in user_context:
                context_str += f"Age: {user_context['age']}\n"
            if "gender" in user_context:
                context_str += f"Gender: {user_context['gender']}\n"
            if "prakriti" in user_context:
                context_str += f"Prakriti: {user_context['prakriti']}\n"
            if "conditions" in user_context and user_context["conditions"]:
                context_str += f"Conditions: {', '.join(user_context['conditions'])}\n"
            
            enriched_query = f"{context_str}\nQuestion: {query}"
            logger.info(f"📋 Enriched query with user context")
        else:
            enriched_query = query
        
        return await self.chat(
            query=enriched_query,
            language=language,
            session_id=session_id
        )
    
    # =========================================================================
    # 2. Utility & Automation
    # =========================================================================
    
    async def autopilot(self, query: str) -> AutopilotResponse:
        """
        POST /v1/autopilot - Auto-router for intent detection
        """
        try:
            response = await self._make_request_with_retry(
                "POST",
                f"{self.base_url}/v1/autopilot",
                json={"query": query}
            )
            
            if response.status_code == 200:
                data = response.json()
                intent_str = data.get("intent", "UNKNOWN")
                try:
                    intent = Intent(intent_str)
                except ValueError:
                    intent = Intent.UNKNOWN
                
                logger.info(f"✅ Autopilot: {intent.value}")
                return AutopilotResponse(
                    intent=intent,
                    status=data.get("status", "success")
                )
            else:
                return AutopilotResponse(intent=Intent.CHAT, status="fallback")
        except Exception as e:
            logger.error(f"❌ Autopilot error: {e}")
            return AutopilotResponse(intent=Intent.CHAT, status="error")
    
    async def route_query(self, query: str) -> Dict[str, Any]:
        """
        Smart router - determines intent and returns routing decision
        """
        autopilot_result = await self.autopilot(query)
        
        intent_map = {
            "SHOP_ASSIST": "/shop-assist",
            "BOOKING": "/booking",
            "CHAT": "/chat"
        }
        
        return {
            "intent": autopilot_result.intent.value,
            "should_route": autopilot_result.intent.value != "CHAT",
            "endpoint": intent_map.get(autopilot_result.intent.value, "/chat"),
            "confidence": autopilot_result.confidence
        }
    
    async def fill(self, text: str, schema_definition: str) -> Dict[str, Any]:
        """
        POST /v1/fill - Structured Data Extraction
        """
        try:
            response = await self._make_request_with_retry(
                "POST",
                f"{self.base_url}/v1/fill",
                json={"text": text, "schema_definition": schema_definition}
            )
            
            if response.status_code == 200:
                data = response.json()
                logger.info("✅ Data extraction complete")
                return {
                    "success": True,
                    "extracted_data": data.get("extracted_data", "{}"),
                    "raw": data
                }
            else:
                return {"success": False, "error": f"Status {response.status_code}"}
        except Exception as e:
            logger.error(f"❌ Fill error: {e}")
            return {"success": False, "error": str(e)}
    
    # =========================================================================
    # 3. Specialized Features
    # =========================================================================
    
    async def shop_assist(self, query: str) -> Dict[str, Any]:
        """
        POST /v1/shop_assist - E-commerce helper for product mapping
        """
        try:
            response = await self._make_request_with_retry(
                "POST",
                f"{self.base_url}/v1/shop_assist",
                json={"query": query}
            )
            
            if response.status_code == 200:
                data = response.json()
                logger.info("✅ Shop assist response received")
                return {
                    "success": True,
                    "result": data.get("result", "{}"),
                    "raw": data
                }
            else:
                return {"success": False, "error": f"Status {response.status_code}"}
        except Exception as e:
            logger.error(f"❌ Shop assist error: {e}")
            return {"success": False, "error": str(e)}
    
    async def extract_schedule(self, prescription_text: str) -> ScheduleResult:
        """
        POST /v1/extract_schedule - Reminder AI for prescription times
        """
        try:
            response = await self._make_request_with_retry(
                "POST",
                f"{self.base_url}/v1/extract_schedule",
                json={"prescription_text": prescription_text}
            )
            
            if response.status_code == 200:
                data = response.json()
                schedule_json = data.get("schedule_json", "{}")
                
                try:
                    parsed = json.loads(schedule_json)
                    reminders = parsed.get("reminders", [])
                except:
                    reminders = []
                
                logger.info(f"✅ Extracted {len(reminders)} reminders")
                return ScheduleResult(reminders=reminders, raw_json=schedule_json)
            else:
                return ScheduleResult(reminders=[], raw_json="{}")
        except Exception as e:
            logger.error(f"❌ Schedule extraction error: {e}")
            return ScheduleResult(reminders=[], raw_json="{}")
    
    async def doctor_summary(self, patient_notes: str) -> Dict[str, Any]:
        """
        POST /v1/doctor_summary - Clinical Scribe for patient notes
        """
        try:
            response = await self._make_request_with_retry(
                "POST",
                f"{self.base_url}/v1/doctor_summary",
                json={"patient_notes": patient_notes}
            )
            
            if response.status_code == 200:
                data = response.json()
                logger.info("✅ Doctor summary generated")
                return {
                    "success": True,
                    "summary": data.get("summary_data", ""),
                    "raw": data
                }
            else:
                return {"success": False, "error": f"Status {response.status_code}"}
        except Exception as e:
            logger.error(f"❌ Doctor summary error: {e}")
            return {"success": False, "error": str(e)}
    
    # =========================================================================
    # 4. Analysis & Safety
    # =========================================================================
    
    async def analyze_safety(self, user_text: str) -> SafetyAnalysis:
        """
        POST /v1/analyze_safety - Safety Sentinel for PII, self-harm, emergencies
        """
        try:
            response = await self._make_request_with_retry(
                "POST",
                f"{self.base_url}/v1/analyze_safety",
                json={"user_text": user_text}
            )
            
            if response.status_code == 200:
                data = response.json()
                is_safe = data.get("is_safe", True)
                flags = data.get("flags", [])
                
                risk = "high" if not is_safe else "low"
                logger.info(f"✅ Safety analysis: safe={is_safe}, flags={flags}")
                
                return SafetyAnalysis(
                    is_safe=is_safe,
                    flags=flags,
                    risk_level=risk
                )
            else:
                return SafetyAnalysis(is_safe=True, flags=[], risk_level="unknown")
        except Exception as e:
            logger.error(f"❌ Safety analysis error: {e}")
            return SafetyAnalysis(is_safe=True, flags=["api_error"], risk_level="unknown")
    
    async def detect_emotion(self, query: str) -> EmotionResult:
        """
        POST /v1/detect_emotion - Sentiment Analysis
        """
        try:
            response = await self._make_request_with_retry(
                "POST",
                f"{self.base_url}/v1/detect_emotion",
                json={"query": query}
            )
            
            if response.status_code == 200:
                data = response.json()
                result_str = data.get("result", "{}")
                
                try:
                    parsed = json.loads(result_str)
                    emotion = parsed.get("emotion", "Unknown")
                    intensity = parsed.get("intensity", "Unknown")
                except json.JSONDecodeError:
                    emotion = "Unknown"
                    intensity = "Unknown"
                
                logger.info(f"✅ Emotion detected: {emotion} ({intensity})")
                return EmotionResult(emotion=emotion, intensity=intensity)
            else:
                return EmotionResult(emotion="Error", intensity="Error", confidence=0.0)
        except Exception as e:
            logger.error(f"❌ Emotion detection error: {e}")
            return EmotionResult(emotion="Error", intensity="Error", confidence=0.0)

    async def profile_analysis(self, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        POST /v1/profile_analysis - Buddy matching/risk assessment
        """
        try:
            response = await self._make_request_with_retry(
                "POST",
                f"{self.base_url}/v1/profile_analysis",
                json={"user_data": user_data}
            )
            if response.status_code == 200:
                data = response.json()
                logger.info("✅ Profile analysis complete")
                return {"success": True, "analysis": data.get("analysis", {}), "raw": data}
            else:
                return {"success": False, "error": f"Status {response.status_code}"}
        except Exception as e:
            logger.error(f"❌ Profile analysis error: {e}")
            return {"success": False, "error": str(e)}

    async def generate_wellness(self, condition: str) -> Dict[str, Any]:
        """
        POST /v1/generate_wellness - Meditation/yoga generation
        """
        try:
            response = await self._make_request_with_retry(
                "POST",
                f"{self.base_url}/v1/generate_wellness",
                json={"condition": condition}
            )
            if response.status_code == 200:
                data = response.json()
                logger.info("✅ Wellness plan generated")
                return {"success": True, "plan": data.get("plan", ""), "raw": data}
            else:
                return {"success": False, "error": f"Status {response.status_code}"}
        except Exception as e:
            logger.error(f"❌ Wellness generation error: {e}")
            return {"success": False, "error": str(e)}

    async def adjust_tone(self, text: str, target_tone: str = "empathetic") -> Dict[str, Any]:
        """
        POST /v1/adjust_tone - Empathetic text rewriting
        """
        try:
            response = await self._make_request_with_retry(
                "POST",
                f"{self.base_url}/v1/adjust_tone",
                json={"text": text, "target_tone": target_tone}
            )
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Tone adjusted to {target_tone}")
                return {"success": True, "adjusted_text": data.get("adjusted_text", text), "raw": data}
            else:
                return {"success": False, "error": f"Status {response.status_code}"}
        except Exception as e:
            logger.error(f"❌ Tone adjustment error: {e}")
            return {"success": False, "error": str(e)}

# ============================================================================
# Dependency Injection / Instance Management
# ============================================================================

# Global instance
_brain_client_instance: Optional[AstraBrainClient] = None

def get_brain_client() -> AstraBrainClient:
    """
    FastAPI dependency to get or create the AstraBrainClient singleton.
    """
    global _brain_client_instance
    if _brain_client_instance is None:
        _brain_client_instance = AstraBrainClient()
    return _brain_client_instance
