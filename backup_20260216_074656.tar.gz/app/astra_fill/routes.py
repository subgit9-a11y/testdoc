from fastapi import APIRouter, HTTPException, UploadFile, File, Form, Depends
from typing import Optional, Dict, Any
from app.astra_fill.models import (
    AstraFillExtraction, 
    AstraFillConfirmationRequest,
    HealthIntakeSchema
)
from app.astra_fill.service import astra_fill_service
import logging

router = APIRouter(prefix="/astra-fill", tags=["Astra Fill"])
logger = logging.getLogger(__name__)

@router.post("/process-voice", response_model=Dict[str, Any])
async def process_voice(
    audio: UploadFile = File(...),
    user_id: str = Form(...),
    language_code: str = Form("en-IN")
):
    """
    Process a voice intake via Astra Pipeline.
    """
    try:
        from app.astra.routes import pipeline_instance
        from app.astra.voice_service import VoiceService
        
        audio_data = await audio.read()
        voice_service = VoiceService(stt_provider="whisper")
        asr_result = await voice_service.speech_to_text(audio_data, language_code=language_code)
        transcript = asr_result.get("transcript", "")
        
        if not transcript:
            raise HTTPException(status_code=400, detail="No speech detected")

        result = await pipeline_instance.run(
            input_text=transcript,
            user_uuid=user_id,
            channel="voice",
            metadata={"feature": "astra_fill"}
        )
        return result
    except Exception as e:
        logger.error(f"Voice fill failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/process-text", response_model=Dict[str, Any])
async def process_text(
    text: str = Form(...),
    user_id: str = Form(...)
):
    """
    Process text intake via Astra Pipeline.
    """
    try:
        from app.astra.routes import pipeline_instance
        result = await pipeline_instance.run(
            input_text=text,
            user_uuid=user_id,
            channel="app",
            metadata={"feature": "astra_fill"}
        )
        return result
    except Exception as e:
        logger.error(f"Text fill failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/confirm")
async def confirm_extraction(request: AstraFillConfirmationRequest):
    """
    Confirm and apply the extracted health details.
    """
    success = await astra_fill_service.confirm_extraction(request)
    if not success:
        raise HTTPException(status_code=400, detail="Confirmation failed or extraction expired")
    
    return {"status": "success", "message": "Health details confirmed and saved"}
