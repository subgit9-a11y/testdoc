import logging
import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List

from app.astra_fill.models import (
    AstraFillExtraction, 
    HealthIntakeSchema, 
    ConfidenceLevel,
    AstraFillConfirmationRequest
)
from app.astra_fill.extraction import HealthExtractor
from app.model_service import model_service
from app.astra.voice_service import VoiceService
from app.indictrans2_service import indictrans2_service
from app.language_utils import language_manager

logger = logging.getLogger(__name__)

class AstraFillService:
    def __init__(self):
        self.extractor = HealthExtractor(model_service)
        self.voice_service = VoiceService(stt_provider="whisper")
        # In-memory store for pending extractions (V1)
        # In production, this should be in Redis or Supabase
        self.pending_extractions: Dict[str, AstraFillExtraction] = {}

    async def process_voice_intake(self, audio_data: bytes, user_id: str, language_code: str = "en-IN") -> Any:
        # ...
        # (Using Any for simplicity to avoid import Tuple if not present, but the structure is extraction, id)
        asr_result = await self.voice_service.speech_to_text(audio_data, language_code=language_code)
        transcript = asr_result.get("transcript", "")
        
        if not transcript:
            raise ValueError("No speech detected in audio")

        return await self.process_text_intake(transcript, user_id, source="voice")

    async def process_text_intake(self, text: str, user_id: str, source: str = "text") -> Any:
        """
        Full pipeline for text intake: Detect -> Normalize -> Extract -> Merge Memory
        """
        # 2. Language Detection & Normalization
        detection_result = language_manager.enhanced_language_detection(text)
        detected_lang = detection_result.get("language", "en")
        
        normalized_text = text
        if detected_lang != "en":
            # Translate to English for extraction
            translation_result = await indictrans2_service.translate(text, detected_lang, "en")
            if translation_result.get("success"):
                normalized_text = translation_result.get("translation")
            else:
                logger.warning(f"Normalization failed for language {detected_lang}, using original text")

        # 3. Information Extraction
        extraction_result = await self.extractor.extract_health_details(normalized_text, language="en")
        
        # 4. Create Extraction Object
        extraction_id = str(uuid.uuid4())
        astra_extraction = AstraFillExtraction(
            structured_data=HealthIntakeSchema(**extraction_result["structured_data"]),
            confidences=extraction_result["confidences"],
            raw_transcript=text,
            normalized_text=normalized_text,
            language=detected_lang,
            source=f"astra_fill_{source}",
            timestamp=datetime.utcnow().isoformat()
        )
        
        # Store for confirmation gate
        self.pending_extractions[extraction_id] = astra_extraction
        
        return astra_extraction, extraction_id

    async def confirm_extraction(self, request: AstraFillConfirmationRequest) -> bool:
        """
        Handles the user confirmation gate.
        Merges confirmed data into the system/RAG.
        """
        if not request.user_confirmed:
            logger.info(f"Extraction {request.extraction_id} rejected by user")
            return False

        extraction = self.pending_extractions.get(request.extraction_id)
        if not extraction:
            logger.error(f"Extraction ID {request.extraction_id} not found")
            return False

        # Use confirmed data from request (user might have edited)
        final_data = request.confirmed_data

        # 5. Merge with RAG / Database (Mocked for V1)
        # TODO: Implement actual RAG update or database save
        logger.info(f"✅ Confirmed health intake for session {request.session_id}: {final_data.dict()}")
        
        # Remove from pending
        del self.pending_extractions[request.extraction_id]
        
        return True

# Global singleton
astra_fill_service = AstraFillService()
