"""
Automated Prescription Service
Orchestrates the entire post-prescription workflow:
1. Database Persistence
2. Shopify Draft Order Creation
3. PDF Generation & Storj Upload
4. Patient Notifications (WhatsApp/Email)
5. Medicine Reminder Scheduling
"""

import logging
import uuid
import tempfile
import os
from datetime import datetime, timezone
from typing import Optional, Dict, List, Any
from sqlalchemy.orm import Session

from app.database_models import (
    PrescriptionRecord, 
    PrescribedMedicine, 
    PatientProfile,
    DocumentRecord
)
from app.shopify_models import PrescriptionRequest
from app.shopify_client import shopify_client
from app.prescription_pdf_service import prescription_pdf_service
from app.storj_client import StorjClient
from app.medicine_reminders.reminder_engine import ReminderEngine
logger = logging.getLogger(__name__)

# Initialize Clients
try:
    storj_client = StorjClient()
except Exception as e:
    logger.warning(f"Storj client not available: {e}")
    storj_client = None

reminder_engine = ReminderEngine()

# Handle WhatsApp Client Import Safely
try:
    from app.medicine_reminders.custom_whatsapp_client import CustomWhatsAppClient as MetaWhatsAppClient
    whatsapp_client = MetaWhatsAppClient()
    logger.info("✅ WhatsApp client initialized for prescription service")
except (ImportError, Exception) as e:
    logger.warning(f"⚠️ WhatsApp client not available, using mock: {e}")
    # Minimal mock to prevent AttributeError/TypeError
    class MockWhatsAppClient:
        async def send_text_message(self, *args, **kwargs):
            logger.info("Mock WA: Message suppressed (Client not available)")
            return {"status": "mocked", "success": True}
        async def send_media_message(self, *args, **kwargs): return {"success": True}
        async def send_template_message(self, *args, **kwargs): return {"success": True}
        async def send_interactive_message(self, *args, **kwargs): return {"success": True}
    
    whatsapp_client = MockWhatsAppClient()

class AutomatedPrescriptionService:
    async def process_prescription(
        self, 
        db: Session, 
        prescription_data: PrescriptionRequest,
        doctor_id: str,
        patient_id: str
    ) -> Dict[str, Any]:
        """
        Main entry point for automated prescription workflow.
        """
        results = {
            "success": False,
            "prescription_id": None,
            "shopify_order": None,
            "pdf_url": None,
            "reminders_created": False,
            "notifications_sent": False,
            "errors": []
        }

        try:
            # 1. Generate unique Prescription ID
            prescription_id = f"PRES-{uuid.uuid4().hex[:8].upper()}"
            results["prescription_id"] = prescription_id

            # 2. Create Shopify Draft Order
            shopify_res = None
            try:
                shopify_res = shopify_client.create_draft_order(prescription_data)
                results["shopify_order"] = {
                    "draft_order_id": shopify_res.draft_order_id,
                    "invoice_url": shopify_res.invoice_url
                }
            except Exception as e:
                logger.error(f"Shopify order creation failed: {e}")
                results["errors"].append(f"Shopify Error: {str(e)}")

            # 3. Save to Database
            record = PrescriptionRecord(
                prescription_id=prescription_id,
                patient_id=patient_id,
                doctor_id=doctor_id,
                diagnosis=prescription_data.diagnosis,
                notes=prescription_data.doctor_notes or "",
                draft_order_id=shopify_res.draft_order_id if shopify_res else None,
                invoice_url=shopify_res.invoice_url if shopify_res else None,
                total_amount=shopify_res.total_price if shopify_res else "0.00",
                status='created'
            )
            db.add(record)
            
            # Save Medicines
            for item in prescription_data.prescriptions:
                medicine = PrescribedMedicine(
                    prescription_id=prescription_id,
                    medicine_name=item.medicine,
                    quantity=item.quantity,
                    dose=item.dose,
                    schedule=item.schedule,
                    timing=item.timing,
                    duration=item.duration or "As directed",
                    instructions=item.instructions or ""
                )
                db.add(medicine)
            
            db.commit()
            db.refresh(record)

            # 4. Generate PDF & Upload to Storj
            pdf_data = None
            try:
                pdf_data = prescription_pdf_service.generate_prescription_pdf(prescription_data)
                if pdf_data and storj_client:
                    with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp:
                        tmp.write(pdf_data)
                        tmp_path = tmp.name
                    
                    try:
                        storj_key = storj_client.upload_document(
                            file_path=tmp_path,
                            patient_id=patient_id,
                            doc_type='prescription',
                            metadata={'prescription_id': prescription_id}
                        )
                        
                        if storj_key:
                            # Generate public link
                            results["pdf_url"] = storj_client.generate_download_url(storj_key)
                            
                            # Record document in DB
                            doc_record = DocumentRecord(
                                document_id=str(uuid.uuid4()),
                                patient_id=patient_id,
                                doc_type='prescription',
                                original_filename=f"Prescription_{prescription_id}.pdf",
                                storj_object_key=storj_key,
                                related_prescription_id=prescription_id
                            )
                            db.add(doc_record)
                            db.commit()
                    finally:
                        if os.path.exists(tmp_path):
                            os.remove(tmp_path)
            except Exception as e:
                logger.error(f"PDF/Storj workflow failed: {e}")
                results["errors"].append(f"Storage Error: {str(e)}")

            # 5. Schedule Reminders
            try:
                reminders_ok = reminder_engine.create_medicine_schedules_from_prescription(prescription_id)
                results["reminders_created"] = reminders_ok
            except Exception as e:
                logger.error(f"Reminder scheduling failed: {e}")
                results["errors"].append(f"Reminder Error: {str(e)}")

            # 6. Send WhatsApp Notification
            if shopify_res and shopify_res.invoice_url:
                try:
                    patient = db.query(PatientProfile).filter(PatientProfile.patient_id == patient_id).first()
                    phone = patient.phone if patient else prescription_data.patient.contact
                    
                    if phone:
                        msg = (
                            f"🌿 *AyurEze: Your Prescription is Ready!*\n\n"
                            f"Diagnosis: {prescription_data.diagnosis}\n"
                            f"Invoice URL: {shopify_res.invoice_url}\n"
                        )
                        if results["pdf_url"]:
                            msg += f"Download PDF: {results['pdf_url']}\n"
                        
                        msg += "\nWe've also scheduled your medicine reminders in the app. Get well soon!"
                        
                        await whatsapp_client.send_text_message(phone, msg)
                        results["notifications_sent"] = True
                        
                        record.notification_sent = True
                        record.notified_at = datetime.now(timezone.utc)
                        db.commit()
                except Exception as e:
                    logger.error(f"WhatsApp notification failed: {e}")
                    results["errors"].append(f"Notification Error: {str(e)}")

            results["success"] = True
            return results

        except Exception as e:
            db.rollback()
            logger.error(f"Critical error in prescription automation: {e}")
            results["errors"].append(f"Critical Error: {str(e)}")
            return results

# Global Instance
automated_prescription_service = AutomatedPrescriptionService()
