import logging
from app.database_models import SessionLocal, PatientCareState
from app.autopilot_engine import AutopilotEngine

logger = logging.getLogger(__name__)

def run_daily_autopilot_check():
    """
    Scheduled task to run the Autopilot Engine for all enabled patients.
    """
    logger.info("🤖 Starting Daily Autopilot Check...")
    
    # Create a new session for MySQL (Events)
    db = SessionLocal()
    if not db:
        logger.error("Could not create database session")
        return

    try:
        engine = AutopilotEngine(db)
        # Use state manager to get patients (Supabase)
        enabled_patients = engine.state_manager.get_enabled_patients()
        
        logger.info(f"Found {len(enabled_patients)} patients with Autopilot enabled.")
        
        for patient_id in enabled_patients:
            try:
                result = engine.evaluate_patient(patient_id)
                # Log interesting results
                if result.get('status') == 'action_prepared':
                    action_type = result.get('action', {}).get('type')
                    logger.info(f"✨ ACTIONS PREPARED for {patient_id}: {action_type}")
                
            except Exception as e:
                logger.error(f"Error evaluating patient {patient_id}: {e}")
                
    except Exception as e:
        logger.error(f"Global Autopilot Scheduler Error: {e}")
    finally:
        db.close()
        logger.info("Daily Autopilot Check Completed.")
