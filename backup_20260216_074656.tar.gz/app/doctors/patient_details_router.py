"""
Aggregated Patient Details Router for Doctors
Provides a comprehensive view of patient history, AI intake, and profile details.
"""

import logging
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from pydantic import BaseModel

from app.database_models import (
    get_db_dependency, 
    PatientProfile, 
    Consultation, 
    PrescriptionRecord,
    PrescribedMedicine
)
from app.astra_fill.service import astra_fill_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/doctors/patient-view", tags=["Doctor View"])

# Pydantic Models for Response
class PatientComprehensiveView(BaseModel):
    patient_profile: Dict[str, Any]
    latest_astra_fill: Optional[Dict[str, Any]] = None
    recent_consultations: List[Dict[str, Any]] = []
    prescription_history: List[Dict[str, Any]] = []

@router.get("/{patient_id}", response_model=PatientComprehensiveView)
async def get_patient_comprehensive_view(
    patient_id: str, 
    db: Session = Depends(get_db_dependency)
):
    """
    Fetch all relevant patient details for the doctor to review before/during prescription.
    """
    try:
        # 1. Get Patient Profile
        patient = db.query(PatientProfile).filter(PatientProfile.patient_id == patient_id).first()
        if not patient:
            # Try searching by patient_code if patient_id not found
            patient = db.query(PatientProfile).filter(PatientProfile.patient_code == patient_id).first()
            if not patient:
                raise HTTPException(status_code=404, detail="Patient not found")
            patient_id = patient.patient_id # Normalize to patient_id

        # 2. Get Latest Astra Fill (AI Intake)
        # Search pending extractions logic
        latest_fill = None
        for ext_id, extraction in astra_fill_service.pending_extractions.items():
            # In V1, we match by some identifier or just take the latest for now
            # In V2, these will be tied to patient_id in database
            latest_fill = extraction.dict()
            break # Just take one for now if available

        # 3. Get Recent Consultations (Last 5)
        consultations = db.query(Consultation).filter(
            Consultation.patient_id == patient_id
        ).order_by(Consultation.created_at.desc()).limit(5).all()

        # 4. Get Prescription History (Last 5)
        prescriptions = db.query(PrescriptionRecord).filter(
            PrescriptionRecord.patient_id == patient_id
        ).order_by(PrescriptionRecord.created_at.desc()).limit(5).all()

        # Build response
        return PatientComprehensiveView(
            patient_profile={
                "id": patient.id,
                "patient_id": patient.patient_id,
                "patient_code": patient.patient_code,
                "name": patient.name,
                "age": patient.age,
                "gender": patient.gender,
                "email": patient.email,
                "phone": patient.phone,
                "medical_conditions": patient.medical_conditions,
                "allergies": patient.allergies
            },
            latest_astra_fill=latest_fill,
            recent_consultations=[{
                "consultation_id": c.consultation_id,
                "doctor_name": c.doctor_name,
                "diagnosis": c.diagnosis,
                "notes": c.notes,
                "date": c.appointment_date or c.created_at
            } for c in consultations],
            prescription_history=[{
                "prescription_id": p.prescription_id,
                "diagnosis": p.diagnosis,
                "total_amount": p.total_amount,
                "status": p.status,
                "date": p.prescribed_at
            } for p in prescriptions]
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching comprehensive patient view: {e}")
        raise HTTPException(status_code=500, detail="Internal server error while fetching patient view")
