"""
Model inference handling with LoRA adapter loading

ARCHITECTURE:
- NO model loading at import time
- Models loaded via async load_model() method
- Integrates with model_registry for centralized management
- Supports both local model inference and remote API
"""

import asyncio
import logging
import gc
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)

# Defer torch import to avoid loading at import time
_torch = None
_transformers_loaded = False


def _get_torch():
    """Lazy load torch"""
    global _torch
    if _torch is None:
        import torch
        _torch = torch
    return _torch


class ModelInference:
    """
    Handles model loading and inference operations.
    
    IMPORTANT: No model loading at init time - all loading is deferred.
    """
    
    def __init__(self, base_model_id: str, lora_model_id: str, device: str = "auto"):
        self.base_model_id = base_model_id
        self.lora_model_id = lora_model_id
        self.device = device
        self.model = None
        self.tokenizer = None
        self.loaded = False
        
        # Don't load anything here
        logger.info(f"ModelInference configured (base: {base_model_id}, lora: {lora_model_id})")
        
    async def load_model(self):
        """Load the base model and LoRA adapter in background thread"""
        try:
            logger.info(f"Loading base model: {self.base_model_id}")
            
            # Run the heavy loading in a thread pool
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self._load_model_sync)
            
            self.loaded = True
            logger.info("Model loaded successfully")
            
            # Log memory usage
            torch = _get_torch()
            if torch.cuda.is_available():
                logger.info(f"GPU memory allocated: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
                logger.info(f"GPU memory cached: {torch.cuda.memory_reserved() / 1024**3:.2f} GB")
            
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            self.loaded = False
            raise
    
    def _load_model_sync(self):
        """Synchronous model loading (runs in thread pool)"""
        torch = _get_torch()
        from transformers import (
            AutoTokenizer, 
            AutoModelForCausalLM, 
            BitsAndBytesConfig
        )
        from peft import PeftModel
        
        # Configure quantization for T4 GPU
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16
        )
        
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.base_model_id,
            trust_remote_code=True,
            padding_side="left"
        )
        
        # Set pad token if not present
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Load base model with quantization
        self.model = AutoModelForCausalLM.from_pretrained(
            self.base_model_id,
            quantization_config=bnb_config,
            device_map="auto",
            trust_remote_code=True,
            torch_dtype=torch.bfloat16,
            attn_implementation="flash_attention_2" if torch.cuda.is_available() else "eager"
        )
        
        logger.info(f"Loading LoRA adapter: {self.lora_model_id}")
        
        # Load LoRA adapter
        self.model = PeftModel.from_pretrained(
            self.model,
            self.lora_model_id,
            torch_dtype=torch.bfloat16
        )
        
        # Enable evaluation mode
        self.model.eval()
        
        # Merge LoRA weights for better inference performance
        try:
            logger.info("Merging LoRA adapter weights...")
            self.model = self.model.merge_and_unload()
        except Exception as e:
            logger.warning(f"Could not merge LoRA weights: {e}. Continuing with adapter.")
    
    def is_loaded(self) -> bool:
        """Check if model is loaded"""
        return self.loaded and self.model is not None and self.tokenizer is not None
    
    async def generate_response(
        self,
        prompt: str,
        max_length: int = 512,
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 50,
        do_sample: bool = True
    ) -> str:
        """Generate response using the loaded model"""
        
        if not self.is_loaded():
            raise RuntimeError("Model is not loaded")
        
        try:
            torch = _get_torch()
            
            # Format prompt for Ayurveda context
            formatted_prompt = self._format_ayurveda_prompt(prompt)
            
            # Tokenize input
            inputs = self.tokenizer(
                formatted_prompt,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=2048
            )
            
            # Move to GPU if available
            if torch.cuda.is_available():
                inputs = {k: v.cuda() for k, v in inputs.items()}
            
            # Generate response
            with torch.no_grad():
                outputs = self.model.generate(
                    input_ids=inputs["input_ids"],
                    attention_mask=inputs["attention_mask"],
                    max_new_tokens=max_length,
                    temperature=temperature,
                    top_p=top_p,
                    top_k=top_k,
                    do_sample=do_sample,
                    pad_token_id=self.tokenizer.eos_token_id,
                    eos_token_id=self.tokenizer.eos_token_id,
                    repetition_penalty=1.1,
                    length_penalty=1.0
                )
            
            # Decode response
            generated_text = self.tokenizer.decode(
                outputs[0][inputs["input_ids"].shape[1]:], 
                skip_special_tokens=True
            )
            
            # Clean up the response
            response = self._clean_response(generated_text)
            
            # Clear cache to prevent memory issues
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            
            return response
            
        except Exception as e:
            logger.error(f"Error during generation: {e}")
            raise RuntimeError(f"Generation failed: {str(e)}")
    
    def _format_ayurveda_prompt(self, prompt: str) -> str:
        """Format prompt for Ayurveda context"""
        system_prompt = """You are an expert Ayurvedic practitioner with deep knowledge of traditional Indian medicine. Provide accurate, helpful information about Ayurvedic principles, treatments, herbs, and practices. Always emphasize consulting with qualified practitioners for medical advice.

User: """
        
        return f"{system_prompt}{prompt}\n\nAyurvedic Expert: "
    
    def _clean_response(self, response: str) -> str:
        """Clean and format the generated response"""
        response = response.strip()
        
        # Remove common end-of-text tokens
        for token in ['[END]', '[end]', 'END_TEXT']:
            response = response.replace(token, '')
        
        # Ensure proper sentence ending
        if response and not response.endswith(('.', '!', '?')):
            last_end = max(response.rfind('.'), response.rfind('!'), response.rfind('?'))
            if last_end > len(response) * 0.7:
                response = response[:last_end + 1]
        
        return response
    
    def cleanup(self):
        """Clean up model resources"""
        if self.model is not None:
            del self.model
            self.model = None
        
        if self.tokenizer is not None:
            del self.tokenizer
            self.tokenizer = None
        
        # Clear GPU cache if available
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass
        
        # Force garbage collection
        gc.collect()
        
        self.loaded = False
        logger.info("Model resources cleaned up")
