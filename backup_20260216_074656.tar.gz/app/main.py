from fastapi import FastAPI
from app.enhanced_inference import AstraModelInference
from app.astra.pipeline import AstraPipeline
from app.astra.router import router as astra_router
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("AstraMain")

app = FastAPI(title="Astra AI Engine")

model = AstraModelInference()

@app.on_event("startup")
async def startup():
    await model.load_model()
    from app.astra import router
    router.pipeline = AstraPipeline(model)
    logger.info("[INFO] Astra fully online (LLaMA only)")

@app.on_event("shutdown")
def shutdown():
    model.cleanup()

app.include_router(astra_router)

@app.get("/health")
def health():
    return {"status": "ok", "astra": "online"}
