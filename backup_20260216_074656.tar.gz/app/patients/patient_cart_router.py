"""
Patient Auto-Cart Integration Router
Allows the Patient App to retrieve the latest prescribed medicines and a direct checkout link.
"""

import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Dict, Any, Optional
from pydantic import BaseModel

from app.database_models import (
    get_db_dependency, 
    PrescriptionRecord, 
    PrescribedMedicine,
    PatientProfile
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/patients/active-cart", tags=["Patient App Integration"])

class CartItem(BaseModel):
    medicine_name: str
    quantity: int
    price: Optional[str] = None
    is_available: bool = True

class ActiveCartResponse(BaseModel):
    has_active_cart: bool
    prescription_id: Optional[str] = None
    diagnosis: Optional[str] = None
    total_amount: Optional[str] = None
    invoice_url: Optional[str] = None
    items: List[CartItem] = []
    message: Optional[str] = None

@router.get("/{patient_id}", response_model=ActiveCartResponse)
async def get_active_prescription_cart(
    patient_id: str, 
    db: Session = Depends(get_db_dependency)
):
    """
    Retrieve the latest unpaid prescription for a patient.
    Provides the Shopify invoice URL for one-click checkout in the patient app.
    """
    try:
        # 1. Verify patient exists
        patient = db.query(PatientProfile).filter(PatientProfile.patient_id == patient_id).first()
        if not patient:
            # Try by code if ID fails
            patient = db.query(PatientProfile).filter(PatientProfile.patient_code == patient_id).first()
            if not patient:
                raise HTTPException(status_code=404, detail="Patient not found")
            patient_id = patient.patient_id

        # 2. Get latest PrescriptionRecord for patient that is unpaid/created
        # We look for 'pending' payment status or 'created'/'notified' prescription status
        prescription = db.query(PrescriptionRecord).filter(
            PrescriptionRecord.patient_id == patient_id,
            PrescriptionRecord.payment_status == 'pending'
        ).order_by(PrescriptionRecord.created_at.desc()).first()
        
        if not prescription:
            return ActiveCartResponse(
                has_active_cart=False, 
                message="No pending prescription cart found for this patient."
            )
            
        # 3. Get line items
        items = db.query(PrescribedMedicine).filter(
            PrescribedMedicine.prescription_id == prescription.prescription_id
        ).all()
        
        return ActiveCartResponse(
            has_active_cart=True,
            prescription_id=prescription.prescription_id,
            diagnosis=prescription.diagnosis,
            total_amount=prescription.total_amount,
            invoice_url=prescription.invoice_url,
            items=[CartItem(
                medicine_name=i.medicine_name,
                quantity=i.quantity,
                price=i.unit_price,
                is_available=i.is_available
            ) for i in items]
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching active cart for patient {patient_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error while fetching cart link")
