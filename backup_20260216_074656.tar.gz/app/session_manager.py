"""
Session Management for Astra - Ayurvedic Wellness Assistant
Handles persistent sessions and session tokens
"""

import uuid
import secrets
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from app.database import db_manager
import logging

logger = logging.getLogger(__name__)

class SessionManager:
    """Manages user sessions and session tokens using Supabase"""
    
    def __init__(self, session_duration_hours: int = 24 * 7):  # 1 week default
        self.session_duration_hours = session_duration_hours
    
    def generate_session_token(self) -> str:
        """Generate a secure session token"""
        return secrets.token_urlsafe(32)
    
    async def create_session(self, user_info: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new user session after Firebase authentication using Supabase"""
        try:
            # Upsert user in Supabase
            user = await db_manager.upsert_user(user_info)
            if not user:
                raise Exception("Failed to upsert user in Supabase")
            
            # Generate session token and expiry
            session_token = self.generate_session_token()
            expires_at = datetime.now(timezone.utc) + timedelta(hours=self.session_duration_hours)
            
            # Create session in Supabase
            session = await db_manager.create_user_session(user["id"], session_token, expires_at)
            
            logger.info(f"Created session in Supabase for user {user['id']}")
            
            return {
                "session_token": session_token,
                "session_id": str(session["id"]),
                "user": {
                    "id": user["id"],
                    "email": user["email"],
                    "name": user.get("name"),
                    "picture": user.get("picture"),
                    "email_verified": user.get("email_verified", False)
                },
                "expires_at": expires_at.isoformat()
            }
        
        except Exception as e:
            logger.error(f"Failed to create session: {e}")
            raise
    
    async def get_session(self, session_token: str) -> Optional[Dict[str, Any]]:
        """Get session information from Supabase by token"""
        try:
            session = await db_manager.get_user_session(session_token)
            
            if not session:
                return None
            
            # Check if session has expired
            expires_at_str = session.get("expires_at")
            if expires_at_str:
                expires_at = datetime.fromisoformat(expires_at_str.replace('Z', '+00:00'))
                if datetime.now(timezone.utc) > expires_at:
                    logger.info(f"Session {session['id']} has expired")
                    await self.invalidate_session(session_token)
                    return None
            
            user = session.get("astra_users", {})
            return {
                "session_id": str(session["id"]),
                "user_id": session["user_id"],
                "user": {
                    "id": user.get("id"),
                    "email": user.get("email"),
                    "name": user.get("name"),
                    "picture": user.get("picture"),
                    "email_verified": user.get("email_verified", False)
                },
                "created_at": session.get("created_at"),
                "last_accessed": session.get("last_accessed"),
                "expires_at": session.get("expires_at")
            }
        
        except Exception as e:
            logger.error(f"Failed to get session from Supabase: {e}")
            return None
    
    async def invalidate_session(self, session_token: str) -> bool:
        """Invalidate a session in Supabase (logout)"""
        try:
            if not db_manager.client: return False
            res = db_manager.client.table("astra_sessions").update({"is_active": False}).eq("session_token", session_token).execute()
            if res.data:
                logger.info(f"Invalidated session {res.data[0]['id']}")
                return True
            return False
        except Exception as e:
            logger.error(f"Failed to invalidate session: {e}")
            return False
    
    async def cleanup_expired_sessions(self) -> int:
        """Clean up expired sessions from Supabase"""
        try:
            if not db_manager.client: return 0
            current_time = datetime.now(timezone.utc).isoformat()
            res = db_manager.client.table("astra_sessions").update({"is_active": False}).lt("expires_at", current_time).eq("is_active", True).execute()
            count = len(res.data) if res.data else 0
            logger.info(f"Cleaned up {count} expired sessions in Supabase")
            return count
        except Exception as e:
            logger.error(f"Failed to cleanup expired sessions: {e}")
            return 0

# Global session manager instance
session_manager = SessionManager()