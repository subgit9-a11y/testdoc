-- ============================================================================
-- ASTRA AI - SUPABASE SCHEMA (Hybrid Architecture)
-- Run this script in your Supabase SQL Editor to create the necessary tables.
-- ============================================================================

-- 1. CHAT HISTORY MANAGEMENT
-- Stores all chat sessions and messages for the Astra AI Assistant.

CREATE TABLE IF NOT EXISTS public.chat_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL, -- Links to your User table (Firebase UID or Auth0 ID)
    language TEXT DEFAULT 'en',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    metadata JSONB DEFAULT '{}'::jsonb
);

-- Index for fast lookup by user
CREATE INDEX IF NOT EXISTS idx_chat_sessions_user ON public.chat_sessions(user_id);

CREATE TABLE IF NOT EXISTS public.chat_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES public.chat_sessions(id) ON DELETE CASCADE,
    user_message TEXT NOT NULL,
    assistant_response TEXT NOT NULL,
    language TEXT DEFAULT 'en',
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- Index for fast retrieval of session history
CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON public.chat_messages(session_id);


-- 2. ASTRA AUTOPILOT STATE
-- Stores the behavioral state for the Autopilot Engine.
-- This replaces the MySQL implementation of `PatientCareState`.

CREATE TABLE IF NOT EXISTS public.patient_care_states (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id TEXT NOT NULL UNIQUE, -- Links to your Legacy MySQL Patient ID
    
    -- Autopilot Switch
    is_autopilot_enabled BOOLEAN DEFAULT FALSE,
    
    -- Observation Signals ( synced from MySQL )
    last_consultation_date TIMESTAMP WITH TIME ZONE,
    last_consultation_id TEXT,
    active_prescription_id TEXT,
    medicine_end_date TIMESTAMP WITH TIME ZONE,

    -- Calculated Windows
    next_followup_window_start TIMESTAMP WITH TIME ZONE,
    next_followup_window_end TIMESTAMP WITH TIME ZONE,

    -- State Machine
    care_journey_stage TEXT DEFAULT 'new', -- new, consultation_done, treatment_active, needs_review, dropped_off
    
    -- Draft Actions (The "Pending" work)
    pending_autopilot_action JSONB, -- e.g. {"type": "booking_draft", "payload": {...}}
    
    last_autopilot_check TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- Index for the daily scheduler to find enabled patients quickly
CREATE INDEX IF NOT EXISTS idx_autopilot_enabled ON public.patient_care_states(is_autopilot_enabled);


-- 3. ASTRA CONSENT MANAGER
-- Stores user consent records for DISHA compliance.

CREATE TABLE IF NOT EXISTS public.astra_consents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    purpose TEXT NOT NULL, -- e.g., 'astra_usage', 'document_upload'
    
    granted BOOLEAN DEFAULT FALSE,
    granted_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    expires_at TIMESTAMP WITH TIME ZONE,
    revoked_at TIMESTAMP WITH TIME ZONE,
    
    is_active BOOLEAN DEFAULT TRUE,
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_consents_lookup ON public.astra_consents(user_id, profile_id, purpose);


-- 4. ASTRA RAG MEMORY (Fallback Storage)
-- Backup storage for RAG vectors/metadata if FAISS is not persistent.

CREATE TABLE IF NOT EXISTS public.astra_rag_memory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id TEXT NOT NULL,
    memory_type TEXT NOT NULL, -- e.g., 'user_preferences'
    
    content TEXT NOT NULL,
    full_metadata JSONB DEFAULT '{}'::jsonb,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    expires_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_rag_profile ON public.astra_rag_memory(profile_id);


-- 5. ENABLE ROW LEVEL SECURITY (Optional/Recommended)
-- Uncomment these lines if you want to restrict access via Supabase Auth rules.
-- ALTER TABLE public.chat_sessions ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.patient_care_states ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.astra_consents ENABLE ROW LEVEL SECURITY;
