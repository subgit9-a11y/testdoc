"""
Astra Brain API Routes - Unified API Endpoints for api.ayureze.in Integration
Version: 1.0.0
Description: Exposes all AI capabilities from api.ayureze.in as REST endpoints

Endpoints:
- POST /brain/chat - Core conversational AI
- POST /brain/autopilot - Intent routing
- POST /brain/fill - Data extraction
- POST /brain/shop-assist - Product recommendations
- POST /brain/extract-schedule - Reminder extraction
- POST /brain/doctor-summary - Clinical notes summary
- POST /brain/analyze-safety - Safety analysis
- POST /brain/detect-emotion - Sentiment analysis
- POST /brain/profile-analysis - Buddy/risk analysis
- POST /brain/generate-wellness - Meditation/yoga content
- POST /brain/adjust-tone - Empathetic rewriting
- GET /brain/health - Brain connection status
"""

import logging
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List

from app.astra_brain_client import get_brain_client, AstraBrainClient

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/brain", tags=["Astra Brain AI"])


# ============================================================================
# Request/Response Models
# ============================================================================

class ChatRequest(BaseModel):
    query: str = Field(..., description="User's message or question")
    language: str = Field(default="en", description="Response language: en, hi, ta")

class AutopilotRequest(BaseModel):
    query: str = Field(..., description="User's text to route")

class FillRequest(BaseModel):
    text: str = Field(..., description="Raw text to extract data from")
    schema_definition: str = Field(..., description="Schema definition for extraction")

class ShopAssistRequest(BaseModel):
    query: str = Field(..., description="Product/symptom query")

class ScheduleRequest(BaseModel):
    prescription_text: str = Field(..., description="Prescription text to parse")

class DoctorSummaryRequest(BaseModel):
    patient_notes: str = Field(..., description="Patient notes to summarize")

class SafetyRequest(BaseModel):
    user_text: Optional[str] = Field(None, description="Text to analyze for safety")
    text: Optional[str] = Field(None, description="Alias for user_text")
    query: Optional[str] = Field(None, description="Alias for user_text")
    message: Optional[str] = Field(None, description="Alias for user_text")

    def __init__(self, **data):
        super().__init__(**data)
        # Normalize to user_text
        if not self.user_text:
            self.user_text = self.text or self.query or self.message or ""

class EmotionRequest(BaseModel):
    query: str = Field(..., description="Text to detect emotion from")

class ProfileAnalysisRequest(BaseModel):
    profile_data_a: str = Field(..., description="First profile data (JSON string)")
    task: str = Field(default="buddy_match", description="Analysis task")
    profile_data_b: Optional[str] = Field(default=None, description="Second profile (optional)")

class WellnessRequest(BaseModel):
    topic: str = Field(..., description="Wellness topic: Sleep Meditation, Yoga for Back Pain, etc.")
    duration: str = Field(default="5 mins", description="Content duration")

class ToneRequest(BaseModel):
    text: str = Field(..., description="Text to rewrite")
    target_tone: str = Field(default="empathetic", description="Target tone: polite, empathetic, professional")


# ============================================================================
# API Endpoints
# ============================================================================

@router.get("/health")
async def brain_health():
    """
    Check Astra Brain connection status.
    Returns model info and connection status.
    """
    brain = get_brain_client()
    result = await brain.check_health()
    
    return {
        "brain_url": brain.base_url,
        "status": result.get("status"),
        "data": result.get("data"),
        "connected": result.get("status") == "online"
    }


@router.post("/chat")
async def brain_chat(request: ChatRequest):
    """
    Main conversational AI endpoint.
    Uses RAG + Agent Persona for responses.
    """
    brain = get_brain_client()
    result = await brain.chat(request.query, request.language)
    
    return {
        "success": result.success,
        "answer": result.answer,
        "mode": result.mode
    }


@router.post("/autopilot")
async def brain_autopilot(request: AutopilotRequest):
    """
    Intent routing - determines where to send user.
    Returns: CHAT, SHOP_ASSIST, BOOKING, etc.
    """
    brain = get_brain_client()
    result = await brain.autopilot(request.query)
    
    return {
        "intent": result.intent.value,
        "status": result.status,
        "should_route": result.intent.value != "CHAT"
    }


@router.post("/fill")
async def brain_fill(request: FillRequest):
    """
    Structured data extraction from text.
    Converts messy text to clean JSON based on schema.
    """
    brain = get_brain_client()
    result = await brain.fill(request.text, request.schema_definition)
    
    return result


@router.post("/shop-assist")
async def brain_shop_assist(request: ShopAssistRequest):
    """
    E-commerce helper - maps symptoms to products.
    """
    brain = get_brain_client()
    result = await brain.shop_assist(request.query)
    
    return result


@router.post("/extract-schedule")
async def brain_extract_schedule(request: ScheduleRequest):
    """
    Reminder AI - extracts times from prescription text.
    """
    brain = get_brain_client()
    result = await brain.extract_schedule(request.prescription_text)
    
    return {
        "reminders": result.reminders,
        "raw_json": result.raw_json
    }


@router.post("/doctor-summary")
async def brain_doctor_summary(request: DoctorSummaryRequest):
    """
    Clinical Scribe - summarizes patient notes for doctors.
    """
    brain = get_brain_client()
    result = await brain.doctor_summary(request.patient_notes)
    
    return result


@router.post("/analyze-safety")
async def brain_analyze_safety(request: SafetyRequest):
    """
    Safety Sentinel - checks for PII, self-harm, emergencies.
    """
    brain = get_brain_client()
    result = await brain.analyze_safety(request.user_text)
    
    return {
        "is_safe": result.is_safe,
        "flags": result.flags,
        "risk_level": result.risk_level
    }


@router.post("/detect-emotion")
async def brain_detect_emotion(request: EmotionRequest):
    """
    Sentiment Analysis - detects emotional state.
    """
    brain = get_brain_client()
    result = await brain.detect_emotion(request.query)
    
    return {
        "emotion": result.emotion,
        "intensity": result.intensity
    }


@router.post("/profile-analysis")
async def brain_profile_analysis(request: ProfileAnalysisRequest):
    """
    Predictive Analytics - buddy matching or risk assessment.
    """
    brain = get_brain_client()
    result = await brain.profile_analysis(
        profile_data_a=request.profile_data_a,
        task=request.task,
        profile_data_b=request.profile_data_b
    )
    
    return result


@router.post("/generate-wellness")
async def brain_generate_wellness(request: WellnessRequest):
    """
    Wellness Content Generator - meditations, yoga plans, tips.
    """
    brain = get_brain_client()
    result = await brain.generate_wellness(request.topic, request.duration)
    
    return result


@router.post("/adjust-tone")
async def brain_adjust_tone(request: ToneRequest):
    """
    Tone Adjuster - rewrites text to be more empathetic/professional.
    """
    brain = get_brain_client()
    result = await brain.adjust_tone(request.text, request.target_tone)
    
    return result


# ============================================================================
# Utility Endpoints
# ============================================================================

@router.get("/endpoints")
async def list_brain_endpoints():
    """
    List all available brain API endpoints.
    """
    return {
        "base_url": "https://api.ayureze.in",
        "endpoints": [
            {"path": "/v1/chat", "method": "POST", "description": "Core conversational AI"},
            {"path": "/v1/autopilot", "method": "POST", "description": "Intent routing"},
            {"path": "/v1/fill", "method": "POST", "description": "Data extraction"},
            {"path": "/v1/shop_assist", "method": "POST", "description": "Product recommendations"},
            {"path": "/v1/extract_schedule", "method": "POST", "description": "Reminder extraction"},
            {"path": "/v1/doctor_summary", "method": "POST", "description": "Clinical notes summary"},
            {"path": "/v1/analyze_safety", "method": "POST", "description": "Safety analysis"},
            {"path": "/v1/detect_emotion", "method": "POST", "description": "Sentiment analysis"},
            {"path": "/v1/profile_analysis", "method": "POST", "description": "Profile analytics"},
            {"path": "/v1/generate_wellness", "method": "POST", "description": "Wellness content"},
            {"path": "/v1/adjust_tone", "method": "POST", "description": "Tone adjustment"},
            {"path": "/health", "method": "GET", "description": "Health check"}
        ],
        "integration_status": "connected"
    }
