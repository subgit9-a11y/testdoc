"""
Supabase database integration for chat history management
"""

import os
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
from supabase import create_client, Client
import logging

logger = logging.getLogger(__name__)

class SupabaseManager:
    """Manages Supabase database operations for chat history"""
    
    def __init__(self):
        self.url = os.getenv("SUPABASE_URL")
        self.key = os.getenv("SUPABASE_KEY")  # Changed from SUPABASE_ANON_KEY
        self.client: Optional[Client] = None
        
        if self.url and self.key:
            try:
                self.client = create_client(self.url, self.key)
                logger.info("Supabase client initialized successfully")
            except Exception as e:
                # User requested to suppress detailed error logs for Supabase
                logger.info(f"Supabase connection skipped (running in offline mode): {e}")
                self.client = None
        else:
            logger.info("Supabase credentials not found, running without database")
    
    def is_connected(self) -> bool:
        """Check if Supabase client is available"""
        return self.client is not None
    
    async def create_chat_session(self, user_id: str, language: str = "en") -> Optional[str]:
        """Create a new chat session"""
        if not self.client:
            return None
            
        try:
            session_data = {
                "user_id": user_id,
                "language": language,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
            
            response = self.client.table("chat_sessions").insert(session_data).execute()
            
            if response.data:
                session_id = response.data[0]["id"]
                logger.info(f"Created chat session: {session_id}")
                return session_id
            return None
            
        except Exception as e:
            logger.error(f"Error creating chat session: {e}")
            return None
    
    async def save_chat_message(
        self, 
        session_id: str, 
        user_message: str, 
        assistant_response: str,
        language: str = "en",
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Save a chat message exchange"""
        if not self.client:
            return False
            
        try:
            message_data = {
                "session_id": session_id,
                "user_message": user_message,
                "assistant_response": assistant_response,
                "language": language,
                "metadata": metadata or {},
                "created_at": datetime.now(timezone.utc).isoformat()
            }
            
            response = self.client.table("chat_messages").insert(message_data).execute()
            
            # Update session timestamp
            self.client.table("chat_sessions").update({
                "updated_at": datetime.now(timezone.utc).isoformat()
            }).eq("id", session_id).execute()
            
            return bool(response.data)
            
        except Exception as e:
            logger.error(f"Error saving chat message: {e}")
            return False
    
    async def get_chat_history(self, session_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Get chat history for a session"""
        if not self.client:
            return []
            
        try:
            response = self.client.table("chat_messages").select("*").eq(
                "session_id", session_id
            ).order("created_at", desc=False).limit(limit).execute()
            
            return response.data or []
            
        except Exception as e:
            logger.error(f"Error getting chat history: {e}")
            return []
    
    async def get_user_sessions(self, user_id: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Get chat sessions for a user"""
        if not self.client:
            return []
            
        try:
            response = self.client.table("chat_sessions").select("*").eq(
                "user_id", user_id
            ).order("updated_at", desc=True).limit(limit).execute()
            
            return response.data or []
            
        except Exception as e:
            logger.error(f"Error getting user sessions: {e}")
            return []
    
    async def delete_session(self, session_id: str, user_id: str) -> bool:
        """Delete a chat session and its messages"""
        if not self.client:
            return False
            
        try:
            # Delete messages first
            self.client.table("chat_messages").delete().eq("session_id", session_id).execute()
            
            # Delete session
            response = self.client.table("chat_sessions").delete().eq("id", session_id).eq(
                "user_id", user_id
            ).execute()
            
            return bool(response.data)
            
        except Exception as e:
            logger.error(f"Error deleting session: {e}")
            return False

    # --- FAMILY SYSTEM ---
    async def get_family_profile(self, primary_patient_id: str) -> Optional[Dict[str, Any]]:
        """Get or create family profile for a patient"""
        if not self.client: return None
        try:
            res = self.client.table("family_profiles").select("*").eq("primary_patient_id", primary_patient_id).execute()
            if res.data: return res.data[0]
            
            # Create if doesn't exist
            new_profile = {
                "primary_patient_id": primary_patient_id,
                "name": f"Family Profile ({primary_patient_id[:8]})"
            }
            res = self.client.table("family_profiles").insert(new_profile).execute()
            return res.data[0] if res.data else None
        except Exception as e:
            logger.error(f"Family profile error: {e}")
            return None

    async def add_family_member(self, member_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Add a family member to Supabase"""
        if not self.client: return None
        try:
            # Ensure family profile exists
            family = await self.get_family_profile(member_data["primary_patient_id"])
            if not family: return None
            
            new_member = {
                "family_id": family["family_id"],
                "name": member_data["name"],
                "relation": member_data["relation"],
                "age": member_data.get("age"),
                "gender": member_data.get("gender"),
                "permissions": member_data.get("permissions", {"view": True, "remind": True})
            }
            res = self.client.table("family_members").insert(new_member).execute()
            return res.data[0] if res.data else None
        except Exception as e:
            logger.error(f"Add family member error: {e}")
            return None

    async def get_family_members(self, primary_patient_id: str) -> List[Dict[str, Any]]:
        """Get all family members from Supabase"""
        if not self.client: return []
        try:
            family = await self.get_family_profile(primary_patient_id)
            if not family: return []
            
            res = self.client.table("family_members").select("*").eq("family_id", family["family_id"]).execute()
            return res.data or []
        except Exception as e:
            logger.error(f"Get family members error: {e}")
            return []

    # --- HEALTH TIMELINE ---
    async def log_health_event(self, event_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Log health event to Supabase"""
        if not self.client: return None
        try:
            event = {
                "patient_id": event_data["patient_id"],
                "event_type": event_data["event_type"],
                "summary": event_data["summary"],
                "source": event_data["source"],
                "metadata": event_data.get("metadata", {})
            }
            res = self.client.table("health_events").insert(event).execute()
            return res.data[0] if res.data else None
        except Exception as e:
            logger.error(f"Log health event error: {e}")
            return None

    # --- AUDIT LOGS ---
    async def log_audit(self, action: str, details: Dict[str, Any], patient_id: str = None, doctor_id: str = None):
        """Log audit entry to Supabase"""
        if not self.client: return
        try:
            audit = {
                "action": action,
                "details": details,
                "patient_id": patient_id,
                "doctor_id": doctor_id,
                "source": "astra"
            }
            self.client.table("audit_logs").insert(audit).execute()
        except Exception as e:
            logger.error(f"Audit log error: {e}")

    # --- USER & SESSION MANAGEMENT ---
    async def upsert_user(self, user_info: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create or update user in Supabase"""
        if not self.client: return None
        try:
            user_id = user_info["user_id"]
            user_data = {
                "id": user_id,
                "email": user_info.get("email"),
                "name": user_info.get("name"),
                "picture": user_info.get("picture"),
                "email_verified": user_info.get("email_verified", False),
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
            # Use upsert (match on id)
            res = self.client.table("astra_users").upsert(user_data).execute()
            return res.data[0] if res.data else None
        except Exception as e:
            logger.error(f"Upsert user error: {e}")
            return None

    async def create_user_session(self, user_id: str, session_token: str, expires_at: datetime = None) -> Optional[Dict[str, Any]]:
        """Create a new user session in Supabase"""
        if not self.client: return None
        try:
            session_data = {
                "user_id": user_id,
                "session_token": session_token,
                "expires_at": expires_at.isoformat() if expires_at else None,
                "is_active": True,
                "created_at": datetime.now(timezone.utc).isoformat()
            }
            res = self.client.table("astra_sessions").insert(session_data).execute()
            return res.data[0] if res.data else None
        except Exception as e:
            logger.error(f"Create session error: {e}")
            return None

    async def get_user_session(self, session_token: str) -> Optional[Dict[str, Any]]:
        """Get active user session by token from Supabase"""
        if not self.client: return None
        try:
            res = self.client.table("astra_sessions").select("*, astra_users(*)").eq("session_token", session_token).eq("is_active", True).execute()
            return res.data[0] if res.data else None
        except Exception as e:
            logger.error(f"Get session error: {e}")
            return None

# Global database manager instance
db_manager = SupabaseManager()