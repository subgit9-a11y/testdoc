import os
from sqlalchemy import create_engine, inspect
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    print("DATABASE_URL not found in .env")
    exit(1)

try:
    engine = create_engine(DATABASE_URL)
    inspector = inspect(engine)
    
    tables = inspector.get_table_names()
    print(f"Tables in database: {tables}")
    
    if "doctors" in tables:
        print("\nStructure of 'doctors' table:")
        columns = inspector.get_columns("doctors")
        for column in columns:
            print(f" - {column['name']}: {column['type']}")
    else:
        print("\n'doctors' table not found.")

except Exception as e:
    print(f"Error connecting to database: {e}")
