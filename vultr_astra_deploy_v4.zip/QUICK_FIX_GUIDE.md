# 🚀 QUICK FIX GUIDE - Apply Before Deployment

**Date:** January 10, 2026  
**Status:** ✅ **CRITICAL FIXES APPLIED AUTOMATICALLY**

---

## ✅ FIXES ALREADY APPLIED

### **1. Fixed `main_enhanced.py` (CRITICAL)**
- ✅ Copied `main.py` to `main_enhanced.py`
- ✅ File is now 40,476 bytes (was 0 bytes)
- ✅ Dockerfile will now work correctly

### **2. Fixed `nginx.conf` (CRITICAL)**
- ✅ Removed SSL/HTTPS configuration
- ✅ HTTP-only mode for initial deployment
- ✅ Increased timeouts for model loading (300s)
- ✅ Added buffer size optimizations

---

## ⚠️ MANUAL STEPS REQUIRED

### **STEP 1: Create `.env` File (CRITICAL)**

```bash
cd vultr_astra
cp .env.example .env
```

Then edit `.env` and update these **REQUIRED** values:

```env
# CRITICAL - Get full key from Supabase Dashboard
SUPABASE_ANON_KEY=<PASTE_FULL_JWT_TOKEN_HERE>

# Verify these are correct
DATABASE_URL=mysql+pymysql://u656934180_ayureze_admin:nemke2%2Dzokroj%2DFibfez@82.25.125.50:3306/u656934180_ayureze
SHOPIFY_ACCESS_TOKEN=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
```

**How to get SUPABASE_ANON_KEY:**
1. Go to https://supabase.com/dashboard
2. Select your project
3. Go to Settings → API
4. Copy the "anon/public" key (full JWT token)

---

### **STEP 2: Create Required Directories**

```bash
cd vultr_astra
mkdir -p audio_cache static
chmod 755 audio_cache static
```

---

### **STEP 3: Verify Vultr Server Specs**

**Minimum Requirements:**
- RAM: 16 GB (32 GB recommended)
- CPU: 8 cores
- Storage: 50 GB SSD
- OS: Ubuntu 22.04 LTS

**Check your server:**
```bash
# Check RAM
free -h

# Check CPU
nproc

# Check disk space
df -h
```

---

## 🚀 DEPLOYMENT COMMANDS

### **On Your Local Machine:**

```bash
# 1. Upload to Vultr
scp -r vultr_astra/ root@YOUR_VULTR_IP:/opt/

# 2. SSH into Vultr
ssh root@YOUR_VULTR_IP
```

### **On Vultr Server:**

```bash
# 3. Navigate to folder
cd /opt/vultr_astra

# 4. Create .env file (CRITICAL)
cp .env.example .env
nano .env  # Edit and save

# 5. Create directories
mkdir -p audio_cache static

# 6. Install Docker (if not installed)
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# 7. Install Docker Compose
apt-get install docker-compose-plugin -y

# 8. Build and run
docker-compose build
docker-compose up -d

# 9. Check logs
docker-compose logs -f backend
```

---

## 🔍 VERIFICATION

### **Check if containers are running:**
```bash
docker-compose ps
```

**Expected output:**
```
NAME                IMAGE               STATUS
aibackend           vultr_astra_backend Up
aibackend_proxy     nginx:latest        Up
```

### **Test the API:**
```bash
# Health check
curl http://localhost/health

# Astra health
curl http://localhost/astra/health

# Detailed health
curl http://localhost/health/detailed
```

---

## 📊 EXPECTED BEHAVIOR

### **First Deployment:**
1. **Build time:** 15-30 minutes (downloading packages)
2. **Container start:** 2-5 minutes
3. **Model loading:** Happens in background
4. **First request:** May take 30-60 seconds (if models still loading)
5. **Subsequent requests:** Fast (< 1 second)

### **Logs to Watch For:**

**✅ GOOD:**
```
✅ Supabase client initialized successfully
✅ Astra Pipeline initialized
✅ Model loading complete! AI is now fully operational
```

**⚠️ WARNINGS (OK):**
```
⚠️ IndicTrans2 pre-loading: <some error>
⚠️ Supabase not available, using in-memory storage
```

**❌ ERRORS (FIX REQUIRED):**
```
❌ Failed to initialize Supabase client
❌ Database initialization failed
❌ ModuleNotFoundError
```

---

## 🆘 TROUBLESHOOTING

### **Issue: Container won't start**
```bash
# Check logs
docker-compose logs backend

# Common causes:
# 1. Missing .env file → Create it
# 2. Invalid environment variables → Check .env
# 3. Port already in use → Change port in docker-compose.yml
```

### **Issue: Out of memory**
```bash
# Add swap space
fallocate -l 8G /swapfile
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile
echo '/swapfile none swap sw 0 0' >> /etc/fstab
```

### **Issue: Slow responses**
```
This is normal for first few requests (model loading).
Wait 5-10 minutes for models to fully load.
Check logs for "Model loading complete" message.
```

---

## ✅ DEPLOYMENT CHECKLIST

- [x] ✅ `main_enhanced.py` fixed (auto-applied)
- [x] ✅ `nginx.conf` simplified (auto-applied)
- [ ] ⚠️ Create `.env` file (MANUAL - REQUIRED)
- [ ] ⚠️ Update `SUPABASE_ANON_KEY` in `.env` (MANUAL - REQUIRED)
- [ ] ⚠️ Create `audio_cache` and `static` directories (MANUAL)
- [ ] ⚠️ Verify Vultr server has 16+ GB RAM (MANUAL)
- [ ] ⚠️ Upload files to Vultr (MANUAL)
- [ ] ⚠️ Run `docker-compose up -d` (MANUAL)

---

## 🎯 SUCCESS CRITERIA

**Deployment is successful when:**
1. ✅ Both containers are running (`docker-compose ps`)
2. ✅ `/health` endpoint returns `{"status": "healthy"}`
3. ✅ `/astra/health` endpoint returns `{"status": "healthy"}`
4. ✅ Logs show "Model loading complete"
5. ✅ API responds to chat requests

---

**Next Step:** Complete the 3 manual steps above, then deploy! 🚀

---

**Generated:** January 10, 2026, 08:49 AM IST  
**Auto-Fixes Applied:** 2/3 critical issues  
**Manual Steps Required:** 3  
**Estimated Time to Deploy:** 30-45 minutes
