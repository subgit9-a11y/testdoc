"""
Astra Brain Client - Unified API Connector for api.ayureze.in
Version: 4.2.1 - Robust Client pooling & Unified Extraction
"""

import logging
import httpx
import asyncio
import json
import re
import os
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)

# ============================================================================
# Data Models
# ============================================================================

class Intent(Enum):
    CHAT = "chat"
    BOOKING = "booking"
    PROFILE = "profile"
    HISTORY = "history"

@dataclass
class ChatResponse:
    answer: str
    mode: str
    success: bool = True

@dataclass
class AutopilotResponse:
    intent: Intent
    status: str
    confidence: float = 1.0

@dataclass
class SafetyAnalysis:
    is_safe: bool
    flags: List[str]
    risk_level: str = "low"

@dataclass
class EmotionResult:
    emotion: str
    intensity: str
    confidence: float = 0.8

@dataclass
class ScheduleResult:
    reminders: List[Dict[str, Any]]
    raw_json: str

# ============================================================================
# Main Client
# ============================================================================

class AstraBrainClient:
    def __init__(self, base_url: str = None):
        self.base_url = (base_url or os.getenv("BRAIN_API_PREFIX", "https://api.ayureze.in")).rstrip("/")
        # New base prefix based on the OpenAPI spec
        self.api_prefix = self.base_url
        
        # Optimize performance: reuse HTTP connection pools and longer timeout
        limits = httpx.Limits(max_keepalive_connections=20, max_connections=50)
        self.timeout = httpx.Timeout(120.0, read=120.0, connect=10.0)
        
        self.client = httpx.AsyncClient(timeout=self.timeout, limits=limits)
        self._connected = False
        logger.info(f"\ud83e\udde0 AstraBrainClient optimized and initialized \u2192 {self.api_prefix}")

    async def close(self):
        """Clean up connections on shutdown"""
        await self.client.aclose()

    async def check_health(self) -> Dict[str, Any]:
        try:
            # Reusing client
            response = await self.client.get(f"{self.api_prefix}/health")
            if 200 <= response.status_code < 300:
                self._connected = True
                return {"status": "online"}
            return {"status": "degraded", "code": response.status_code}
        except Exception as e:
            return {"status": "offline", "error": str(e)}

    async def chat(self, query: str) -> ChatResponse:
        try:
            # Spec expects {"q": "string"}
            response = await self.client.post(f"{self.api_prefix}/v1/chat", json={"q": query})
            if response.status_code != 200:
                logger.error(f"\u274c Chat API Failed: {response.status_code} {response.text}")
                return ChatResponse(answer="API error", mode="error", success=False)
                
            data = response.json()
            # The spec defines "answer" and "mode"
            raw_answer = data.get("answer", data.get("response", "")) or "No response from AI brain."
            return ChatResponse(
                answer=raw_answer.replace("[SYSTEM]:", "").strip(),
                mode=data.get("mode", "chat"),
                success=True
            )
        except Exception as e:
            logger.error(f"\u274c Chat API Exception: {e}")
            return ChatResponse(answer="I'm having trouble connecting to the brain.", mode="error", success=False)

    async def autopilot(self, query: str) -> AutopilotResponse:
        try:
            # Spec expects {"q": "string"}
            response = await self.client.post(f"{self.api_prefix}/v1/autopilot", json={"q": query})
            data = response.json()
            
            # The brain returns a natural language intent string
            intent_str = str(data.get("intent", "CHAT")).lower()
            
            # Heuristic for intent detection
            if any(word in intent_str for word in ["book", "appointment", "doctor", "schedule", "physician"]):
                intent = Intent.BOOKING
            elif any(word in intent_str for word in ["profile", "my info", "account"]):
                intent = Intent.PROFILE
            elif any(word in intent_str for word in ["prescription", "history", "records", "report"]):
                intent = Intent.HISTORY
            else:
                intent = Intent.CHAT
                
            return AutopilotResponse(intent=intent, status="success")
        except Exception:
            return AutopilotResponse(intent=Intent.CHAT, status="error")

    async def fill(self, text: str, schema_definition: str) -> Dict[str, Any]:
        try:
            # Spec expects {"text": "string", "schema_def": "string"}
            response = await self.client.post(f"{self.api_prefix}/v1/fill", json={"text": text, "schema_def": schema_definition})
            raw_data = response.json().get("data", "{}")
            
            # Extraction logic for Markdown JSON - Robust check
            if not isinstance(raw_data, str): 
                return {"success": response.status_code == 200, "extracted_data": raw_data}

            # Try markdown first
            json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', raw_data, re.DOTALL)
            if json_match:
                extracted = json_match.group(1)
            else:
                # Try finding any JSON-like object string
                obj_match = re.search(r'\{.*\}', raw_data, re.DOTALL)
                extracted = obj_match.group(0) if obj_match else raw_data
            
            return {"success": response.status_code == 200, "extracted_data": extracted}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def shop_assist(self, query: str) -> Dict[str, Any]:
        try:
            # Spec expects scalar string content in application/json
            response = await self.client.post(f"{self.api_prefix}/v1/shop_assist", json=query)
            return {"success": response.status_code == 200, "result": response.json().get("result", "{}")}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def extract_schedule(self, text: str) -> ScheduleResult:
        try:
            # v7.5 Spec expects text as scalar body, response has "schedule"
            response = await self.client.post(f"{self.api_prefix}/v1/extract_schedule", json=text)
            if response.status_code != 200:
                return ScheduleResult(reminders=[], raw_json=f"HTTP {response.status_code}")
                
            res = response.json()
            raw_schedule = res.get("schedule", "")
            
            # Extraction logic for Markdown JSON
            json_match = re.search(r'```(?:json)?\s*(.*?)\s*```', raw_schedule, re.DOTALL)
            extracted_str = json_match.group(1) if json_match else raw_schedule
            
            try:
                parsed = json.loads(extracted_str)
                # If brain returned a single reminder dict, wrap it
                reminders = []
                if isinstance(parsed, dict):
                    if "reminders" in parsed: reminders = parsed["reminders"]
                    elif "Reminder" in parsed: reminders = [parsed["Reminder"]]
                    else: reminders = [parsed]
                elif isinstance(parsed, list):
                    reminders = parsed
                
                return ScheduleResult(reminders=reminders, raw_json=json.dumps(parsed))
            except:
                return ScheduleResult(reminders=[], raw_json=raw_schedule)
        except Exception as e:
            logger.error(f"\u274c Extraction API Failed: {e}")
            return ScheduleResult(reminders=[], raw_json=str(e))

    async def doctor_summary(self, patient_notes: str) -> Dict[str, Any]:
        try:
            # Spec expects scalar string content in application/json
            response = await self.client.post(f"{self.api_prefix}/v1/doctor_summary", json=patient_notes)
            if response.status_code != 200:
                return {"success": False, "error": f"API Error {response.status_code}"}
            
            data = response.json()
            if not isinstance(data, dict):
                return {"success": True, "summary": str(data)}
                
            summary = data.get("summary_data", data.get("summary", "")) or "Clinical summary not available."
            return {"success": True, "summary": summary}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def analyze_safety(self, user_text: str) -> SafetyAnalysis:
        try:
            # Spec expects scalar string content in application/json
            response = await self.client.post(f"{self.api_prefix}/v1/analyze_safety", json=user_text)
            if response.status_code != 200:
                return SafetyAnalysis(is_safe=True, flags=[], risk_level="unknown")
            
            data = response.json()
            # Extraction logic for cases where brain returns stringified JSON
            if isinstance(data, str):
                json_match = re.search(r'```(?:json)?\s*(.*?)\s*```', data, re.DOTALL)
                try:
                    data = json.loads(json_match.group(1) if json_match else data)
                except: pass

            if not isinstance(data, dict):
                return SafetyAnalysis(is_safe=True, flags=[], risk_level="low")

            return SafetyAnalysis(
                is_safe=data.get("is_safe", data.get("safe", True)), 
                flags=data.get("flags", []),
                risk_level=data.get("risk_level", "low")
            )
        except Exception:
            return SafetyAnalysis(is_safe=True, flags=[], risk_level="unknown")

    async def detect_emotion(self, query: str) -> EmotionResult:
        try:
            # Spec expects scalar string content in application/json
            response = await self.client.post(f"{self.api_prefix}/v1/detect_emotion", json=query)
            if response.status_code != 200:
                return EmotionResult(emotion="Neutral", intensity="Medium")
            
            d = response.json()
            # Unified extraction
            res_field = d.get("result", d)
            res = {}
            if isinstance(res_field, str):
                json_match = re.search(r'```(?:json)?\s*(.*?)\s*```', res_field, re.DOTALL)
                try:
                    res = json.loads(json_match.group(1) if json_match else res_field)
                except: res = {"emotion": "Neutral", "intensity": "Medium"}
            elif isinstance(res_field, dict):
                res = res_field

            return EmotionResult(
                emotion=str(res.get("emotion", "Neutral")),
                intensity=str(res.get("intensity", "Medium")),
                confidence=float(res.get("confidence", 0.8))
            )
        except Exception:
            return EmotionResult(emotion="Neutral", intensity="Medium")

    async def profile_analysis(self, profile_data_a: str, task: str = "buddy_match", profile_data_b: Optional[str] = None) -> Dict[str, Any]:
        try:
            # Spec expects {"p_a": "string", "task": "string", "p_b": "string | null"}
            payload = {"p_a": profile_data_a, "task": task, "p_b": profile_data_b}
            response = await self.client.post(f"{self.api_prefix}/v1/profile_analysis", json=payload)
            return {"success": response.status_code == 200, "analysis": response.json().get("analysis", "")}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def generate_wellness(self, topic: str, duration: str = "5 mins") -> Dict[str, Any]:
        try:
            # Spec expects {"topic": "string", "duration": "string"}
            response = await self.client.post(f"{self.api_prefix}/v1/generate_wellness", json={"topic": topic, "duration": duration})
            if response.status_code != 200:
                return {"success": False, "error": f"API Error {response.status_code}"}
            
            data = response.json()
            content = data.get("content", data) if isinstance(data, dict) else data
            return {"success": True, "content": str(content)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def adjust_tone(self, text: str, target_tone: str = "polite") -> Dict[str, Any]:
        try:
            # Spec expects {"text": "string", "target_tone": "string"}
            response = await self.client.post(f"{self.api_prefix}/v1/adjust_tone", json={"text": text, "target_tone": target_tone})
            if response.status_code != 200:
                return {"success": False, "rewritten_text": text, "error": f"API Error {response.status_code}"}
            
            data = response.json()
            rewritten = data.get("rewritten_text", data.get("output", data)) if isinstance(data, dict) else data
            return {
                "success": True, 
                "rewritten_text": str(rewritten)
            }
        except Exception as e:
            return {"success": False, "rewritten_text": text, "error": str(e)}

# =========================================================================
# Singleton Instance & Dependency Injection
# =========================================================================

_brain_client = None

def get_brain_client() -> AstraBrainClient:
    """Provides a singleton instance of the AstraBrainClient"""
    global _brain_client
    if _brain_client is None:
        _brain_client = AstraBrainClient()
    return _brain_client

astra_brain = get_brain_client()
