from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum

class ConfidenceLevel(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

class HealthIntakeSchema(BaseModel):
    primary_complaint: str = Field(..., description="The main health issue or reason for intake")
    duration: str = Field(..., description="How long the issue has been present")
    severity_clues: str = Field(..., description="Details about how severe the issue is or what makes it worse")
    pattern_or_timing: str = Field(..., description="When the symptom occurs or its frequency")
    previous_treatment: str = Field(..., description="Any medicines or treatments already tried for this")
    is_follow_up: bool = Field(False, description="Whether this is a follow-up to a previous issue")
    stop_or_gap_sign: Optional[str] = Field(None, description="Signs that treatment was stopped or there was a gap")

class ExtractedField(BaseModel):
    value: Any
    confidence: ConfidenceLevel
    reasoning: Optional[str] = None

class AstraFillExtraction(BaseModel):
    structured_data: HealthIntakeSchema
    confidences: Dict[str, ConfidenceLevel]
    raw_transcript: str
    normalized_text: Optional[str] = None
    language: str
    source: str = "astra_fill"
    timestamp: str

class AstraFillConfirmationRequest(BaseModel):
    session_id: str
    extraction_id: str
    confirmed_data: HealthIntakeSchema
    user_confirmed: bool
