from fastapi import APIRouter, HTTPException, UploadFile, File, Form, Depends
from typing import Optional, Dict, Any
from app.astra_fill.models import (
    AstraFillExtraction, 
    AstraFillConfirmationRequest,
    HealthIntakeSchema
)
from app.astra_fill.service import astra_fill_service
import logging

router = APIRouter(prefix="/astra-fill", tags=["Astra Fill"])
logger = logging.getLogger(__name__)

@router.post("/process-voice", response_model=Dict[str, Any])
async def process_voice(
    audio: UploadFile = File(...),
    user_id: str = Form(...),
    language_code: str = Form("en-IN")
):
    """
    Process a voice intake via Astra Fill Service.
    Returns structured health extraction.
    """
    try:
        audio_data = await audio.read()
        extraction, extraction_id = await astra_fill_service.process_voice_intake(
            audio_data, 
            user_id, 
            language_code=language_code
        )
        
        return {
            "status": "success",
            "extraction_id": extraction_id,
            "data": extraction.model_dump() if hasattr(extraction, "model_dump") else extraction.dict()
        }
    except Exception as e:
        logger.error(f"Voice fill failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/process-text", response_model=Dict[str, Any])
async def process_text(
    text: str = Form(...),
    user_id: str = Form(...)
):
    """
    Process text intake via Astra Fill Service.
    Returns structured health extraction.
    """
    try:
        extraction, extraction_id = await astra_fill_service.process_text_intake(text, user_id)
        
        return {
            "status": "success",
            "extraction_id": extraction_id,
            "data": extraction.model_dump() if hasattr(extraction, "model_dump") else extraction.dict()
        }
    except Exception as e:
        logger.error(f"Text fill failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/voice-assistant", response_model=Dict[str, Any])
async def voice_assistant(
    audio: UploadFile = File(...),
    user_id: str = Form(...),
    language_code: str = Form("en-IN")
):
    """
    Standard Voice Assistant Relay: Audio -> STT -> AI Brain -> Text Response.
    Connects to the text-based AI model at api.ayureze.in
    """
    try:
        audio_data = await audio.read()
        result = await astra_fill_service.process_voice_chat(
            audio_data, 
            user_id, 
            language_code=language_code
        )
        return result
    except Exception as e:
        logger.error(f"Voice assistant relay failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/confirm")
async def confirm_extraction(request: AstraFillConfirmationRequest):
    """
    Confirm and apply the extracted health details.
    """
    success = await astra_fill_service.confirm_extraction(request)
    if not success:
        raise HTTPException(status_code=400, detail="Confirmation failed or extraction expired")
    
    return {"status": "success", "message": "Health details confirmed and saved"}
    
@router.get("/patient/{user_id}/latest")
async def get_latest_intake(user_id: str):
    """
    Get the most recent health intake for a patient.
    """
    data = await astra_fill_service.get_latest_fill(user_id)
    if not data:
        return {}
    return data

@router.get("/patient/{user_id}/history")
async def get_intake_history(user_id: str):
    """
    Get the full health intake history for a patient.
    """
    history = await astra_fill_service.get_fill_history(user_id)
    return history
    
@router.get("/patient/{user_id}/records")
async def get_intake_records(user_id: str):
    """
    Alias for history, used by some app versions.
    """
    history = await astra_fill_service.get_fill_history(user_id)
    return {"records": history}
