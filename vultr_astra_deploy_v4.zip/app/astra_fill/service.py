from app.database import db_manager
import logging
import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List

from app.astra_fill.models import (
    AstraFillExtraction, 
    HealthIntakeSchema, 
    ConfidenceLevel,
    AstraFillConfirmationRequest
)
from app.astra_fill.extraction import HealthExtractor
from app.model_service import model_service
from app.astra.voice_service import VoiceService
from app.indictrans2_service import indictrans2_service
from app.language_utils import language_manager

logger = logging.getLogger(__name__)

class AstraFillService:
    def __init__(self):
        self.extractor = HealthExtractor(model_service)
        self.voice_service = VoiceService(stt_provider="whisper")

    async def process_voice_intake(self, audio_data: bytes, user_id: str, language_code: str = "en-IN") -> Any:
        asr_result = await self.voice_service.speech_to_text(audio_data, language_code=language_code)
        transcript = asr_result.get("transcript", "")
        
        if not transcript:
            raise ValueError("No speech detected in audio")

        return await self.process_text_intake(transcript, user_id, source="voice")

    async def process_text_intake(self, text: str, user_id: str, source: str = "text") -> Any:
        """
        Full pipeline for text intake: Detect -> Normalize -> Extract -> Save to Supabase
        """
        # 2. Language Detection & Normalization
        detection_result = language_manager.enhanced_language_detection(text)
        detected_lang = detection_result.get("language", "en")
        
        normalized_text = text
        if detected_lang != "en":
            # Translate to English for extraction
            translation_result = await indictrans2_service.translate(text, detected_lang, "en")
            if translation_result.get("success"):
                normalized_text = translation_result.get("translation")
            else:
                logger.warning(f"Normalization failed for language {detected_lang}, using original text")

        # 3. Information Extraction
        extraction_result = await self.extractor.extract_health_details(normalized_text, language="en")
        
        # 4. Create Extraction Object
        extraction_id = str(uuid.uuid4())
        astra_extraction = AstraFillExtraction(
            structured_data=HealthIntakeSchema(**extraction_result["structured_data"]),
            confidences=extraction_result["confidences"],
            raw_transcript=text,
            normalized_text=normalized_text,
            language=detected_lang,
            source=f"astra_fill_{source}",
            timestamp=datetime.utcnow().isoformat()
        )
        
        # Store in Supabase for persistence
        if db_manager.is_connected():
            await db_manager.save_astra_fill_extraction(
                extraction_id, 
                user_id, 
                astra_extraction.model_dump() if hasattr(astra_extraction, "model_dump") else astra_extraction.dict()
            )
        else:
            logger.warning("Supabase not connected, extraction will not be persistent across restarts")
        
        return astra_extraction, extraction_id

    async def confirm_extraction(self, request: AstraFillConfirmationRequest) -> bool:
        """
        Handles the user confirmation gate.
        Merges confirmed data into the system/RAG/Supabase.
        """
        if not request.user_confirmed:
            logger.info(f"Extraction {request.extraction_id} rejected by user")
            if db_manager.is_connected():
                await db_manager.update_astra_fill_status(request.extraction_id, "rejected")
            return False

        # Retrieve from Supabase
        extraction_record = None
        if db_manager.is_connected():
            extraction_record = await db_manager.get_astra_fill_extraction(request.extraction_id)
        
        if not extraction_record:
            logger.error(f"Extraction ID {request.extraction_id} not found in database")
            return False

        # Use confirmed data from request (user might have edited)
        final_data = request.confirmed_data

        # 5. Merge with RAG / Database 
        # For now, we update the status in astra_fill_extractions and log
        if db_manager.is_connected():
            await db_manager.update_astra_fill_status(request.extraction_id, "confirmed")
            
            # Optionally update patient profile or clinical notes
            # This could be a future enhancement to sync with EHR
            logger.info(f"✅ Confirmed health intake for user {extraction_record['user_id']}: {final_data.dict()}")
        
        return True
        
    async def get_latest_fill(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve the latest confirmed/pending health intake for a patient"""
        if not db_manager.is_connected():
            return None
        return await db_manager.get_latest_astra_fill(user_id)

    async def get_fill_history(self, user_id: str) -> List[Dict[str, Any]]:
        """Retrieve full health intake history for a patient"""
        if not db_manager.is_connected():
            return []
        return await db_manager.get_astra_fill_history(user_id)

    async def process_voice_chat(self, audio_data: bytes, user_id: str, language_code: str = "en-IN") -> Dict[str, Any]:
        """
        Relay voice audio to STT then to the Astra AI Brain for a response.
        """
        from app.astra_brain_client import astra_brain
        
        # 1. Audio to Text
        asr_result = await self.voice_service.speech_to_text(audio_data, language_code=language_code)
        transcript = asr_result.get("transcript", "")
        
        if not transcript:
            return {"success": False, "error": "No speech detected"}

        # 2. Text to AI Brain
        brain_response = await astra_brain.chat(transcript)
        
        # 3. SAVE to Supabase for persistence
        if db_manager.is_connected():
            await db_manager.save_chat_message(
                user_id=user_id,
                user_message=transcript,
                assistant_response=brain_response.answer,
                language=language_code,
                metadata={"source": "astra_voice_assistant", "voice": True}
            )
            logger.info(f"💾 Persisted voice conversation for user {user_id}")

        return {
            "success": True,
            "transcript": transcript,
            "response": brain_response.answer,
            "mode": brain_response.mode
        }

# Global singleton
astra_fill_service = AstraFillService()
