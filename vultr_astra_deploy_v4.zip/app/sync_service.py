"""
Sync Service - The Ecosystem Bridge
Automatically interlinks Admin Backend (MySQL) with Astra AI Database (Supabase)
"""

import logging
import asyncio
from datetime import datetime, timezone
from sqlalchemy import text
from app.database import db_manager
from app.admin_db import admin_db

logger = logging.getLogger(__name__)

class SyncService:
    """Interlinks MySQL (Admin) and Supabase (AI) systems"""
    
    _instance = None
    _is_running = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SyncService, cls).__new__(cls)
        return cls._instance

    async def start_background_sync(self, interval_seconds: int = 3600):
        """
        Runs a periodic sync task in the background.
        Ensures the AI database always reflects the Admin backend.
        """
        if self._is_running:
            logger.info("SyncService is already running in background")
            return
            
        self._is_running = True
        logger.info(f"🔄 Interlink Background Sync started (Interval: {interval_seconds}s)")
        
        while self._is_running:
            try:
                # Run Sync Task
                logger.info("📦 Synchronizing ecosystem data...")
                summary = await self.sync_all()
                logger.info(f"✅ Sync complete: {summary}")
            except Exception as e:
                logger.error(f"❌ Background sync error: {e}")
            
            # Sleep until next sync
            await asyncio.sleep(interval_seconds)

    async def sync_all(self):
        """Perform a full synchronization of doctors and patients using batching"""
        if not admin_db.engine or not db_manager.is_connected():
            return {"error": "Database not connected"}
            
        doctors_synced = 0
        patients_synced = 0
        
        try:
            # 1. SYNC DOCTORS (Batch)
            doctor_records = []
            with admin_db.get_session() as session:
                try:
                    res = session.execute(text("SELECT id, name, email, phone, specialization, is_active FROM doctors"))
                    for row in res.mappings():
                        doctor_records.append({
                            "doctor_id": f"DOC-{row['id']}",
                            "name": row['name'],
                            "email": row.get('email', ''),
                            "phone": row.get('phone', ''),
                            "specialization": row.get('specialization', 'General Physician'),
                            "is_active": row.get('is_active', 1) == 1
                        })
                except Exception as e:
                    logger.error(f"Failed to fetch doctors from MySQL: {e}")

            if doctor_records:
                # Batch upsert to Supabase (limit per chunk to avoid hitting URL length limits if any)
                chunk_size = 100
                for i in range(0, len(doctor_records), chunk_size):
                    chunk = doctor_records[i:i + chunk_size]
                    db_manager.client.table("doctors").upsert(chunk).execute()
                    doctors_synced += len(chunk)
                logger.info(f"📊 Batch synced {doctors_synced} doctors")

            # 2. SYNC PATIENTS (From users table - Batch)
            patient_records = []
            with admin_db.get_session() as session:
                try:
                    # Limit to avoid massive memory usage on fresh sync
                    res = session.execute(text("SELECT id, name, email, phone FROM users WHERE role = 'patient' LIMIT 2000"))
                    for row in res.mappings():
                        patient_records.append({
                            "patient_id": str(row['id']),
                            "name": row['name'],
                            "email": row.get('email', ''),
                            "phone": row.get('phone', ''),
                        })
                except Exception as e:
                    logger.error(f"Failed to fetch patients from MySQL: {e}")

            if patient_records:
                chunk_size = 100
                for i in range(0, len(patient_records), chunk_size):
                    chunk = patient_records[i:i + chunk_size]
                    db_manager.client.table("patient_profiles").upsert(chunk).execute()
                    patients_synced += len(chunk)
                logger.info(f"📊 Batch synced {patients_synced} patients")

            return {"doctors": doctors_synced, "patients": patients_synced}
            
        except Exception as e:
            logger.error(f"Sync logic error: {e}")
            return {"error": str(e)}

# Export singleton
sync_service = SyncService()
