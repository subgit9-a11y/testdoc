"""
Unified Prescription Workflow (Supabase Powered)
Orchestrates the complete prescription flow using Supabase.
"""

import logging
import tempfile
import os
import uuid
from pathlib import Path
from typing import Optional, Dict, Any
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel

from app.database import db_manager
from app.shopify_models import PrescriptionRequest
from app.prescription_pdf_service import PrescriptionPDFService
from app.storage_factory import storage_client
from app.medicine_reminders.reminder_engine import ReminderEngine

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/prescription-workflow", tags=["Unified Prescription Workflow"])

# Initialize services
pdf_service = PrescriptionPDFService()
reminder_engine = ReminderEngine()

class UnifiedPrescriptionRequest(BaseModel):
    prescription_id: str
    patient_email: Optional[str] = None
    doctor_email: Optional[str] = None
    send_email: bool = True
    upload_to_storj: bool = True # Legacy name, now Wasabi
    create_reminders: bool = True
    share_via_whatsapp: bool = False
    patient_phone: Optional[str] = None

class WorkflowResult(BaseModel):
    success: bool
    prescription_id: str
    pdf_generated: bool
    email_sent: bool
    storj_uploaded: bool
    reminders_created: bool
    whatsapp_shared: bool
    pdf_url: Optional[str] = None
    document_id: Optional[str] = None
    errors: list = []

@router.post("/execute", response_model=WorkflowResult)
async def execute_unified_prescription_workflow(request: UnifiedPrescriptionRequest) -> WorkflowResult:
    """Execute the complete prescription workflow using Supabase"""
    
    result = WorkflowResult(
        success=False,
        prescription_id=request.prescription_id,
        pdf_generated=False,
        email_sent=False,
        storj_uploaded=False,
        reminders_created=False,
        whatsapp_shared=False,
        errors=[]
    )
    
    try:
        # 1. Get prescription from Supabase
        prescription_record = await db_manager.get_prescription(request.prescription_id)
        if not prescription_record:
            raise HTTPException(status_code=404, detail=f"Prescription not found")
        
        # 2. Convert to PrescriptionRequest format
        prescription = _convert_supabase_to_request(prescription_record)
        
        # 3. PDF Generation
        pdf_data = None
        try:
            pdf_data = pdf_service.generate_prescription_pdf(prescription)
            result.pdf_generated = True
        except Exception as e:
            result.errors.append(f"PDF error: {e}")
        
        # 4. Email
        if request.send_email and pdf_data:
            try:
                email_result = pdf_service.send_prescription_email(
                    prescription=prescription,
                    pdf_data=pdf_data,
                    patient_email=request.patient_email
                )
                if email_result.get('email_sent'): result.email_sent = True
            except Exception as e:
                result.errors.append(f"Email error: {e}")
        
        # 5. Wasabi Storage
        if request.upload_to_storj and pdf_data:
            try:
                with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp:
                    tmp.write(pdf_data)
                    tmp_path = tmp.name
                
                try:
                    storage_key = storage_client.upload_document(
                        file_path=tmp_path,
                        patient_id=prescription_record.get('patient_id'),
                        doc_type='prescription'
                    )
                    
                    if storage_key:
                        result.storj_uploaded = True
                        result.document_id = storage_key
                        result.pdf_url = storage_client.generate_download_url(storage_key)
                        
                        # Log PDF in Supabase
                        await db_manager.create_document_record({
                            "document_id": str(uuid.uuid4()),
                            "patient_id": prescription_record.get('patient_id'),
                            "doc_type": 'prescription',
                            "original_filename": f"Prescription_{request.prescription_id}.pdf",
                            "storj_object_key": storage_key,
                            "storage_provider": "wasabi",
                            "related_prescription_id": request.prescription_id
                        })
                finally:
                    if os.path.exists(tmp_path): os.remove(tmp_path)
            except Exception as e:
                result.errors.append(f"Storage error: {e}")

        # 6. Reminders
        if request.create_reminders:
            try:
                # reminder_engine now uses Supabase internally (updated separately)
                await reminder_engine.create_medicine_schedules_from_prescription(request.prescription_id)
                result.reminders_created = True
            except Exception as e:
                result.errors.append(f"Reminder error: {e}")

        result.success = True
        return result
        
    except HTTPException: raise
    except Exception as e:
        logger.error(f"Unified workflow failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

def _convert_supabase_to_request(record: Dict[str, Any]) -> PrescriptionRequest:
    """Helper for converting Supabase JSON record to Pydantic model"""
    from app.shopify_models import PatientInfo, DoctorInfo, PrescriptionItem
    
    patient_info = PatientInfo(
        name=record.get("patient_name", "Patient"),
        contact=record.get("patient_phone", record.get("patient_email", "")),
        age=record.get("patient_age", 0),
        gender=record.get("patient_gender", "Not Specified")
    )
    
    doctor_info = DoctorInfo(
        name=record.get("doctor_name", "Dr. AyurEze"),
        regn_no="AY12345",
        contact="+91 98765 43210"
    )
    
    prescriptions = []
    med_list = record.get("prescribed_medicines", [])
    for med in med_list:
        prescriptions.append(PrescriptionItem(
            medicine=med.get("medicine_name", ""),
            dose=med.get("dose", ""),
            schedule=med.get("schedule", ""),
            duration=med.get("duration", ""),
            timing=med.get("timing", ""),
            quantity=med.get("quantity", 1),
            instructions=med.get("instructions", "")
        ))
    
    return PrescriptionRequest(
        patient=patient_info,
        doctor=doctor_info,
        prescriptions=prescriptions,
        diagnosis=record.get("diagnosis", ""),
        doctor_notes=record.get("notes", "")
    )
